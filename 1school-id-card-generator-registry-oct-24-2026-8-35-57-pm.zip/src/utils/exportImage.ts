import { toPng } from 'html-to-image';

/**
 * Safely exports an HTML element to high-res PNG data URL,
 * preventing SecurityError on cross-origin Google Fonts stylesheets.
 */
export async function safeToPng(element: HTMLElement, pixelRatio = 3): Promise<string> {
  // Wait for any pending fonts to finish loading
  if (document.fonts && document.fonts.ready) {
    try {
      await document.fonts.ready;
    } catch (e) {
      // Ignore font readiness error
    }
  }

  const options = {
    quality: 1.0,
    pixelRatio,
    cacheBust: true,
    fontEmbedCSS: '', // Crucial: bypasses SecurityError on reading document.styleSheets.cssRules
  };

  try {
    return await toPng(element, options);
  } catch (err) {
    console.warn('First toPng attempt failed, retrying with lower pixel ratio:', err);
    return await toPng(element, {
      ...options,
      pixelRatio: 2,
    });
  }
}
