import React from 'react';
import { StudentRecord } from '../types/student';
import { SchoolSeal } from './SchoolSeal';
import { formatBirthDateDisplay } from '../data/sampleStudents';

interface IdCardBackProps {
  student: StudentRecord;
  scale?: number;
  id?: string;
  forceNoCutMargin?: boolean;
}

export const IdCardBack: React.FC<IdCardBackProps> = ({
  student,
  scale = 1,
  id = 'id-card-back',
  forceNoCutMargin = false,
}) => {
  const formattedBirthDate = formatBirthDateDisplay(student.birthDate);

  // Cutting margin allowance (default 3.5mm / 14px on all sides)
  const hasCutMargin = !forceNoCutMargin && (student.includeCuttingMargin ?? true);
  const marginPx = (student.cuttingMarginMm || 3) * 3.78; // convert mm to approx px

  return (
    <div
      style={{
        transform: scale !== 1 ? `scale(${scale})` : undefined,
        transformOrigin: 'top left',
      }}
      className="inline-block"
    >
      {/* Outer Bleed / Cutting Margin Container matching Front */}
      <div
        className={`relative inline-block ${
          hasCutMargin ? 'bg-white p-3 border border-dashed border-slate-300 shadow-sm' : ''
        }`}
        style={{
          padding: hasCutMargin ? `${marginPx}px` : 0,
        }}
      >
        {/* Corner Crop Marks for Cutting Allowance */}
        {hasCutMargin && (
          <>
            {/* Top-Left */}
            <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-slate-400 pointer-events-none" />
            {/* Top-Right */}
            <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-slate-400 pointer-events-none" />
            {/* Bottom-Left */}
            <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-slate-400 pointer-events-none" />
            {/* Bottom-Right */}
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-slate-400 pointer-events-none" />
          </>
        )}

        {/* Card Body - Standard CR80 ID Card (450px x 714px) */}
        <div
          id={id}
          className="relative bg-white text-black overflow-hidden shadow-2xl select-none flex flex-col justify-between"
          style={{
            width: '450px',
            height: '714px',
            minWidth: '450px',
            minHeight: '714px',
          }}
        >
          {/* ================= TOP SECTION (Editable Seal & Validity Sticker Zone) ================= */}
          <div className="pt-6 px-6 text-center flex flex-col items-center">
            {/* Official School Seal / Editable Logo */}
            <div className="mb-2">
              <SchoolSeal size={68} customLogoUrl={student.schoolLogoUrl} />
            </div>

            {/* Validity Header */}
            <h2 className="font-anton italic text-[19px] tracking-wide text-black uppercase leading-tight">
              THIS ID CARD IS VALID THROUGH:
            </h2>

            {/* Sticker Placement Box (No S.Y. printed because manually stickered) */}
            <div className="my-3 py-2 px-6 border border-dashed border-slate-300 rounded bg-slate-50/50">
              <p className="font-sticker text-[11px] tracking-widest text-slate-500 uppercase">
                --PUT YOUR VALIDITY STICKER HERE--
              </p>
            </div>

            {/* Red Warning Notice */}
            <p className="text-[11.5px] font-bold text-red-600 tracking-wide uppercase leading-tight mb-3">
              &quot;NOT VALID WITHOUT A VALIDITY STICKER.&quot;
            </p>
          </div>

          {/* ================= MIDDLE SECTION (Policy & Terms) ================= */}
          <div>
            {/* Black Divider Bar Top */}
            <div className="w-full h-[2.5px] bg-black" />

            {/* NON-TRANSFERABLE HEADER */}
            <div className="py-1 text-center bg-white">
              <h3 className="font-anton text-[19px] tracking-wider text-black uppercase leading-none">
                THIS ID IS NON-TRANSFERABLE
              </h3>
            </div>

            {/* Black Divider Bar Middle */}
            <div className="w-full h-[2.5px] bg-black" />

            {/* School Policy Paragraph */}
            <div className="px-6 py-2.5 text-center">
              <p className="text-[12.5px] font-medium text-black leading-relaxed font-sans-ui">
                The bearer is a bona fide student of {student.schoolName || 'Sulon National High School'}. This card must be worn at all times while on school premises. Any misuse, tampering, or lending of this ID is strictly prohibited. If found, please return it to the Principal&apos;s Office.
              </p>
            </div>

            {/* Black Divider Bar Bottom */}
            <div className="w-full h-[2.5px] bg-black" />
          </div>

          {/* ================= EMERGENCY & CONTACT DETAILS ================= */}
          <div className="px-6 py-2 text-center flex-1 flex flex-col justify-center space-y-3">
            {/* Emergency Contact */}
            <div>
              <h4 className="font-anton text-[16px] tracking-wider text-black uppercase leading-tight">
                IN CASE OF EMERGENCY, PLEASE NOTIFY:
              </h4>
              <div className="text-[14px] font-semibold text-black leading-tight mt-0.5 font-sans-ui">
                {student.emergencyContactName || 'Parent / Guardian Name'}
              </div>
              {student.emergencyContactAddress && (
                <div className="text-[12px] font-normal text-black leading-tight font-sans-ui">
                  {student.emergencyContactAddress}
                </div>
              )}
              <div className="text-[14px] font-bold text-black tracking-wide leading-tight mt-0.5 font-sans-ui">
                {student.emergencyContactPhone || '09XX-XXX-XXXX'}
              </div>
            </div>

            {/* Student Address */}
            <div>
              <h4 className="font-anton text-[15px] tracking-wider text-black uppercase leading-tight">
                STUDENT ADDRESS:
              </h4>
              <div className="text-[12.5px] font-medium text-black leading-tight mt-0.5 font-sans-ui max-w-sm mx-auto">
                {student.studentAddress || 'Barangay, Municipality, Province'}
              </div>
            </div>

            {/* Birth Date */}
            <div>
              <h4 className="font-anton text-[15px] tracking-wider text-black uppercase leading-tight">
                BIRTH DATE:
              </h4>
              <div className="text-[14px] font-semibold text-black leading-tight mt-0.5 font-sans-ui">
                {formattedBirthDate}
              </div>
            </div>
          </div>

          {/* ================= STUDENT SIGNATURE SECTION (Adjusted higher for safe zone) ================= */}
          <div className="pb-11 px-10 text-center">
            {/* Signature Rendering Area */}
            <div className="h-14 w-full flex items-end justify-center relative -mb-1">
              {student.signatureUrl ? (
                <img
                  src={student.signatureUrl}
                  alt="Student Signature"
                  className="max-h-14 max-w-[200px] object-contain drop-shadow-sm"
                />
              ) : (
                <div className="font-script text-2xl text-slate-800 opacity-60 font-semibold select-none pb-0.5">
                  {student.fullName ? student.fullName.toLowerCase().replace(/\b\w/g, (l) => l.toUpperCase()) : ''}
                </div>
              )}
            </div>

            {/* Signature Line */}
            <div className="w-full h-[2px] bg-black mx-auto" />

            {/* Label below line */}
            <div className="font-serif italic text-[14px] text-black tracking-wide mt-1">
              Signature of Student
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
