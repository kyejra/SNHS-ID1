import React from 'react';

interface SchoolSealProps {
  customLogoUrl?: string;
  className?: string;
  size?: number;
  watermark?: boolean;
}

export const SchoolSeal: React.FC<SchoolSealProps> = ({
  customLogoUrl,
  className = '',
  size = 120,
  watermark = false,
}) => {
  // Use uploaded official Sulon National High School logo as default
  const logoSrc = customLogoUrl || '/assets/aistudio/NO_PHOTO_51d01644.png';

  return (
    <div
      style={{ width: `${size}px`, height: `${size}px` }}
      className={`flex items-center justify-center select-none overflow-hidden ${className} ${
        watermark ? 'opacity-20 mix-blend-multiply' : ''
      }`}
    >
      <img
        src={logoSrc}
        alt="Sulon National High School Seal"
        className="w-full h-full object-contain filter drop-shadow-sm"
      />
    </div>
  );
};
