import React from 'react';
import { StudentRecord } from '../types/student';
import { SchoolSeal } from './SchoolSeal';
import { PrincipalSignature } from './PrincipalSignature';
import { User } from 'lucide-react';

interface IdCardFrontProps {
  student: StudentRecord;
  scale?: number;
  id?: string;
  forceNoCutMargin?: boolean;
}

export const IdCardFront: React.FC<IdCardFrontProps> = ({
  student,
  scale = 1,
  id = 'id-card-front',
  forceNoCutMargin = false,
}) => {
  const isSeniorHigh = student.level === 'SENIOR HIGH SCHOOL';
  const isJuniorHigh = student.level === 'JUNIOR HIGH SCHOOL';

  // Dynamic color schemes
  const headerBgStart = student.headerBgStart || '#15803d';
  const headerBgEnd = student.headerBgEnd || '#4ade80';
  const schoolNameColor = student.schoolNameColor || '#fde047';

  const jhsColor = student.juniorHighColor || '#22c55e';
  const jhsStroke = student.juniorHighStrokeColor || '#000000';

  const shsColor = student.seniorHighColor || '#facc15';
  const shsStroke = student.seniorHighStrokeColor || '#000000';

  // Full Name size matches JUNIOR HIGH SCHOOL (36px) by default
  const getFullNameFontSize = (name: string): string => {
    const len = (name || '').trim().length;
    if (len <= 24) return '36px'; // Matches JUNIOR HIGH SCHOOL (36px) exactly
    if (len <= 29) return '32px';
    if (len <= 34) return '28px';
    return '24px'; // Only scales down for very long names
  };

  const nameFontSize = getFullNameFontSize(student.fullName);

  // Cutting margin allowance (default 3.5mm / 14px on all sides)
  const hasCutMargin = !forceNoCutMargin && (student.includeCuttingMargin ?? true);
  const marginPx = (student.cuttingMarginMm || 3) * 3.78; // convert mm to approx px

  return (
    <div
      style={{
        transform: scale !== 1 ? `scale(${scale})` : undefined,
        transformOrigin: 'top left',
      }}
      className="inline-block"
    >
      {/* Outer Bleed / Cutting Margin Container */}
      <div
        className={`relative inline-block ${
          hasCutMargin ? 'bg-white p-3 border border-dashed border-slate-300 shadow-sm' : ''
        }`}
        style={{
          padding: hasCutMargin ? `${marginPx}px` : 0,
        }}
      >
        {/* Corner Crop Marks for Cutting Allowance */}
        {hasCutMargin && (
          <>
            {/* Top-Left */}
            <div className="absolute top-0 left-0 w-3 h-3 border-t-2 border-l-2 border-slate-400 pointer-events-none" />
            {/* Top-Right */}
            <div className="absolute top-0 right-0 w-3 h-3 border-t-2 border-r-2 border-slate-400 pointer-events-none" />
            {/* Bottom-Left */}
            <div className="absolute bottom-0 left-0 w-3 h-3 border-b-2 border-l-2 border-slate-400 pointer-events-none" />
            {/* Bottom-Right */}
            <div className="absolute bottom-0 right-0 w-3 h-3 border-b-2 border-r-2 border-slate-400 pointer-events-none" />
          </>
        )}

        {/* Card Body - Standard CR80 ID Card (450px x 714px) */}
        <div
          id={id}
          className="relative bg-white text-black overflow-hidden shadow-2xl select-none flex flex-col"
          style={{
            width: '450px',
            height: '714px',
            minWidth: '450px',
            minHeight: '714px',
          }}
        >
          {/* ================= TOP HEADER (Editable Color Gradient) ================= */}
          <div
            className="pt-4 pb-2.5 px-3 text-center relative z-10 transition-colors shrink-0"
            style={{
              background: `linear-gradient(180deg, ${headerBgStart} 0%, ${headerBgEnd} 100%)`,
            }}
          >
            {/* Official Administrative Subheaders */}
            <div className="text-[10.5px] font-medium text-white tracking-normal leading-tight font-sans-ui drop-shadow-sm">
              {student.republicHeader || 'Republic of the Philippines'}
            </div>
            <div className="text-[10.5px] font-medium text-white tracking-normal leading-tight font-sans-ui drop-shadow-sm">
              {student.regionHeader || 'Bangsamoro Autonomous Region in Muslim Mindanao'}
            </div>
            <div className="text-[10.5px] font-medium text-white tracking-normal leading-tight font-sans-ui drop-shadow-sm">
              {student.ministryHeader || 'Ministry of Basic, Higher, and Technical Education'}
            </div>
            <div className="text-[10.5px] font-semibold text-white tracking-normal leading-tight font-sans-ui mt-0.5 drop-shadow-sm">
              {student.divisionHeader || 'School Division of Maguindanao del Norte'}
            </div>

            {/* School Name with customizable color and crisp 3D outline */}
            <h1
              className="font-anton text-[28px] leading-tight tracking-wide mt-1 mb-0.5 uppercase drop-shadow-sm"
              style={{
                color: schoolNameColor,
                WebkitTextStroke: '1.5px #000000',
                textShadow:
                  '1.5px 1.5px 0 #000, -1.5px -1.5px 0 #000, 1.5px -1.5px 0 #000, -1.5px 1.5px 0 #000, 0 2px 2px rgba(0,0,0,0.5)',
              }}
            >
              {student.schoolName || 'SULON NATIONAL HIGH SCHOOL'}
            </h1>

            {/* Address */}
            <div className="text-[10.5px] font-bold text-black tracking-normal leading-tight font-sans-ui">
              {student.schoolAddress || 'Solon, Sultan Mastura, Maguindanao del Norte'}
            </div>

            {/* School ID Number */}
            <div className="text-[11.5px] font-black text-black tracking-wider leading-tight font-oswald mt-0.5 uppercase">
              SCHOOL ID NUMBER: <span className="tracking-widest">{student.schoolIdNumber || '326501'}</span>
            </div>
          </div>

          {/* ================= ONE UNIFIED BACKGROUND CONTAINER (From Below Header to Bottom) ================= */}
          <div className="relative flex-1 flex flex-col justify-between overflow-hidden bg-white">
            {/* Single Continuous Background Layer (Plain White by default, or uploaded photo) */}
            {student.backgroundUrl ? (
              <div
                className="absolute inset-0 pointer-events-none bg-cover bg-center transition-all"
                style={{
                  backgroundImage: `url(${student.backgroundUrl})`,
                  opacity: student.backgroundOpacity ?? 0.2,
                  filter: `blur(${student.backgroundBlur ?? 0}px)`,
                }}
              />
            ) : null}

            {/* Watermark Logo (Only rendered if explicitly toggled on) */}
            {student.showFrontLogoWatermark ? (
              <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <SchoolSeal
                  size={260}
                  watermark
                  customLogoUrl={student.schoolLogoUrl}
                />
              </div>
            ) : null}

            {/* 1. Middle Photo & LRN Section */}
            <div className="relative z-10 px-6 pt-5 pb-2 flex items-center justify-between">
              {/* 1x1 Photo Frame with rounded corners & clean white border */}
              <div
                className="w-44 h-44 rounded-3xl overflow-hidden border-[5px] border-white shadow-lg bg-slate-100 flex items-center justify-center relative shrink-0"
                style={{
                  boxShadow: '0 4px 14px rgba(0,0,0,0.18)',
                }}
              >
                {student.photoUrl ? (
                  <div className="w-full h-full overflow-hidden relative">
                    <img
                      src={student.photoUrl}
                      alt={student.fullName}
                      className="w-full h-full object-cover"
                      style={{
                        transform: `scale(${student.photoScale || 1}) translate(${student.photoOffsetX || 0}%, ${student.photoOffsetY || 0}%)`,
                        transformOrigin: 'center center',
                      }}
                      crossOrigin="anonymous"
                    />
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center text-slate-400 p-2 text-center">
                    <User className="w-16 h-16 stroke-1 mb-1 text-slate-400" />
                    <span className="text-[11px] font-bold text-slate-500 font-oswald">1 x 1 PHOTO</span>
                  </div>
                )}
              </div>

              {/* LRN Block with dynamic font auto-adjustment when > 11 digits */}
              <div className="flex-1 pl-6 flex flex-col items-center justify-center text-center">
                <span className="font-oswald text-2xl font-black tracking-wider text-black">
                  LRN:
                </span>
                <span
                  className="font-oswald font-black text-black mt-1 whitespace-nowrap transition-all"
                  style={(() => {
                    const clean = (student.lrn || '134171190015').trim();
                    const len = clean.length;
                    if (len <= 10) return { fontSize: '26px', letterSpacing: '0.12em' };
                    if (len === 11) return { fontSize: '24px', letterSpacing: '0.09em' };
                    if (len === 12) return { fontSize: '21px', letterSpacing: '0.06em' };
                    if (len <= 14) return { fontSize: '18px', letterSpacing: '0.04em' };
                    return { fontSize: '15px', letterSpacing: '0.02em' };
                  })()}
                >
                  {student.lrn || '134171190015'}
                </span>
                {student.trackStrand && (
                  <span className="mt-2 text-[11px] font-bold font-oswald uppercase text-slate-700 bg-white/90 px-2 py-0.5 rounded border border-slate-300 shadow-sm">
                    Strand: {student.trackStrand}
                  </span>
                )}
              </div>
            </div>

            {/* 2. Student Full Name Bar (Same 36px font-anton size as JUNIOR HIGH SCHOOL!) */}
            <div className="relative z-10 text-center py-2 px-3 flex flex-col items-center justify-center">
              <h2
                className="font-anton leading-none tracking-tight text-black uppercase transition-all max-w-[425px] mx-auto drop-shadow-sm"
                style={{
                  fontSize: nameFontSize,
                }}
              >
                {student.fullName || 'STUDENT FULL NAME'}
              </h2>
              <div className="font-oswald font-extrabold text-[12px] tracking-[0.28em] text-black uppercase mt-1">
                STUDENT&apos;S NAME
              </div>
            </div>

            {/* 3. Lower Level Section (JUNIOR / SENIOR HIGH SCHOOL - 36px) - adjusted higher */}
            <div className="relative z-10 text-center px-4 pt-1 pb-2">
              {isJuniorHigh && (
                <h3
                  className="font-anton text-[36px] leading-none tracking-normal uppercase"
                  style={{
                    color: jhsColor,
                    WebkitTextStroke: `2px ${jhsStroke}`,
                    textShadow: `2px 2px 0 ${jhsStroke}, -2px -2px 0 ${jhsStroke}, 2px -2px 0 ${jhsStroke}, -2px 2px 0 ${jhsStroke}, 0 3px 3px rgba(0,0,0,0.4)`,
                  }}
                >
                  JUNIOR HIGH SCHOOL
                </h3>
              )}
              {isSeniorHigh && (
                <h3
                  className="font-anton text-[36px] leading-none tracking-normal uppercase"
                  style={{
                    color: shsColor,
                    WebkitTextStroke: `2px ${shsStroke}`,
                    textShadow: `2px 2px 0 ${shsStroke}, -2px -2px 0 ${shsStroke}, 2px -2px 0 ${shsStroke}, -2px 2px 0 ${shsStroke}, 0 3px 3px rgba(0,0,0,0.4)`,
                  }}
                >
                  SENIOR HIGH SCHOOL
                </h3>
              )}
              {!isJuniorHigh && !isSeniorHigh && (
                <h3
                  className="font-anton text-[36px] leading-none tracking-normal uppercase"
                  style={{
                    color: jhsColor,
                    WebkitTextStroke: `2px ${jhsStroke}`,
                    textShadow: `2px 2px 0 ${jhsStroke}, -2px -2px 0 ${jhsStroke}, 2px -2px 0 ${jhsStroke}, -2px 2px 0 ${jhsStroke}`,
                  }}
                >
                  {student.customLevel || student.level || 'STUDENT'}
                </h3>
              )}
            </div>

            {/* 4. Principal Designation Block - adjusted higher for safe zone */}
            <div className="relative z-10 flex flex-col items-center justify-end pb-8">
              <PrincipalSignature
                customSignatureUrl={student.principalSignatureUrl}
                name={student.principalName || 'LUNA L. SLA'}
                title={student.principalTitle || 'Principal I'}
                showSignature={student.showPrincipalSignature ?? false}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
