import React, { useState } from 'react';
import { StudentRecord } from '../types/student';
import { SAMPLE_STUDENTS, DEFAULT_SCHOOL_CONFIG } from '../data/sampleStudents';
import {
  User,
  CreditCard,
  Phone,
  Calendar,
  PenTool,
  Camera,
  School,
  Lock,
  Unlock,
  Sparkles,
  Save,
  PlusCircle,
  Palette,
  Image as ImageIcon,
  Upload,
  RotateCcw,
  Trash2,
  ShieldCheck,
  ShieldAlert,
  Scissors,
} from 'lucide-react';
import { PhotoEditorModal } from './PhotoEditorModal';
import { SignaturePad } from './SignaturePad';
import { SchoolSeal } from './SchoolSeal';
import { PhilippineAddressSelector } from './PhilippineAddressSelector';

interface StudentFormProps {
  student: StudentRecord;
  onChange: (updated: StudentRecord) => void;
  onSaveToRegistry: () => void;
  onNewStudent: () => void;
  isAdminUnlocked?: boolean;
  onUnlockAdmin?: () => void;
  onLockAdmin?: () => void;
}

export const StudentForm: React.FC<StudentFormProps> = ({
  student,
  onChange,
  onSaveToRegistry,
  onNewStudent,
  isAdminUnlocked: externalIsAdminUnlocked,
  onUnlockAdmin,
  onLockAdmin,
}) => {
  // Navigation between Student Fillable Form and School ID Customization
  const [activeTab, setActiveTab] = useState<'student' | 'customization'>('student');
  
  // Security lock for School ID Customization
  const [localIsAdminUnlocked, setLocalIsAdminUnlocked] = useState<boolean>(false);
  const isAdminUnlocked = externalIsAdminUnlocked !== undefined ? externalIsAdminUnlocked : localIsAdminUnlocked;

  const [adminPinInput, setAdminPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);
  const [showUnlockModal, setShowUnlockModal] = useState<boolean>(false);

  // Modals for photo and signature
  const [showPhotoModal, setShowPhotoModal] = useState(false);
  const [showSignatureModal, setShowSignatureModal] = useState(false);

  // Field updater
  const updateField = <K extends keyof StudentRecord>(key: K, value: StudentRecord[K]) => {
    onChange({
      ...student,
      [key]: value,
      updatedAt: new Date().toISOString(),
    });
  };

  const loadPreset = (presetStudent: StudentRecord) => {
    onChange({
      ...presetStudent,
      id: student.id || `student-${Date.now()}`,
      updatedAt: new Date().toISOString(),
    });
  };

  // Upload Custom School Logo
  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      updateField('schoolLogoUrl', event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  // Upload Custom Background Image
  const handleBackgroundUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      updateField('backgroundUrl', event.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleAdminTabClick = () => {
    if (!isAdminUnlocked) {
      setShowUnlockModal(true);
    } else {
      setActiveTab('customization');
    }
  };

  const unlockAdmin = () => {
    if (onUnlockAdmin) {
      onUnlockAdmin();
    } else {
      setLocalIsAdminUnlocked(true);
    }
    setShowUnlockModal(false);
    setActiveTab('customization');
    setPinError(null);
    setAdminPinInput('');
  };

  const handleVerifyPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPinInput.trim() === '102897') {
      unlockAdmin();
    } else {
      setPinError('Incorrect PIN code. Access denied.');
    }
  };

  const handleLockAdmin = () => {
    if (onLockAdmin) {
      onLockAdmin();
    } else {
      setLocalIsAdminUnlocked(false);
    }
    setActiveTab('student');
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-6 text-white shadow-xl">
      {/* Top Action Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <h2 className="text-lg font-bold text-white flex items-center gap-2 font-oswald uppercase tracking-wide">
              <CreditCard className="w-5 h-5 text-emerald-400" />
              School ID Card Designer
            </h2>
            {isAdminUnlocked ? (
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 flex items-center gap-1">
                <Unlock className="w-3 h-3 text-amber-400" /> Admin Unlocked
              </span>
            ) : (
              <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                <Lock className="w-3 h-3 text-emerald-400" /> Student Mode Protected
              </span>
            )}
          </div>
          <p className="text-xs text-slate-400 mt-0.5">
            {activeTab === 'student'
              ? 'Fill in student details, 1x1 photo, signature & dropdown residence address.'
              : 'School ID Template Customization (Admin Only: Logo, plain/custom background, colors & principal).'}
          </p>
        </div>

        {/* New Student Action (+New only as requested) */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={onNewStudent}
            className="px-3.5 py-1.5 text-xs font-bold rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white shadow-sm transition-colors flex items-center gap-1.5"
          >
            <PlusCircle className="w-3.5 h-3.5 text-white" />
            + New
          </button>
        </div>
      </div>

      {/* STRICT SEPARATION TABS */}
      <div className="grid grid-cols-2 gap-2 p-1 bg-slate-950 rounded-xl border border-slate-800">
        {/* Tab 1: Fillable for Student */}
        <button
          type="button"
          onClick={() => setActiveTab('student')}
          className={`py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'student'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          <User className="w-4 h-4" />
          <span>1. Student Fillable Form</span>
          <span className="text-[10px] px-1.5 py-0.2 bg-emerald-950/80 text-emerald-300 rounded font-normal hidden sm:inline">
            Student Access
          </span>
        </button>

        {/* Tab 2: School ID Customization (Admin Only) */}
        <button
          type="button"
          onClick={handleAdminTabClick}
          className={`py-2.5 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 ${
            activeTab === 'customization'
              ? 'bg-amber-600 text-white shadow-md'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
          }`}
        >
          {isAdminUnlocked ? (
            <Palette className="w-4 h-4 text-amber-300" />
          ) : (
            <Lock className="w-4 h-4 text-amber-400" />
          )}
          <span>2. School ID Customization</span>
          <span className="text-[10px] px-1.5 py-0.2 bg-amber-950/80 text-amber-300 rounded font-normal hidden sm:inline">
            Admin Only
          </span>
        </button>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: STUDENT FILLABLE DETAILS (Only accessible for students to fill out) */}
      {/* ========================================================================= */}
      {activeTab === 'student' && (
        <div className="space-y-6 animate-fade-in">
          {/* Security Notice Badge */}
          <div className="p-3 bg-slate-800/40 border border-slate-700/60 rounded-xl flex items-center justify-between text-xs text-slate-300">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>
                <strong>Fillable Student Mode:</strong> Fill in personal details, photo, and signature. ID colors, logos, and spreadsheet registry are protected for administration.
              </span>
            </div>
            {!isAdminUnlocked && (
              <button
                type="button"
                onClick={() => setShowUnlockModal(true)}
                className="text-[11px] text-amber-400 hover:text-amber-300 underline font-semibold shrink-0 ml-2"
              >
                Admin Unlock
              </button>
            )}
          </div>

          {/* Section 1: Full Name & LRN */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <User className="w-4 h-4" />
              1. Student Identity &amp; Department Level
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Full Name with live length check */}
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    Student Full Name <span className="text-emerald-400">*</span>
                  </label>
                  <span className="text-[11px] text-slate-400 font-mono">
                    {student.fullName.length} chars · Matches 36px font
                  </span>
                </div>
                <input
                  type="text"
                  value={student.fullName}
                  onChange={(e) => updateField('fullName', e.target.value.toUpperCase())}
                  placeholder="e.g. TONGGAL E. ASGAR"
                  className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-white font-semibold uppercase tracking-wide focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* LRN (Learner Reference Number) with dynamic font length indicator */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-300">
                    LRN (Learner Reference Number) <span className="text-emerald-400">*</span>
                  </label>
                  <span className="text-[11px] text-emerald-400 font-mono">
                    {student.lrn.length > 11 ? `${student.lrn.length} digits (Auto-scaled)` : `${student.lrn.length}/12 digits`}
                  </span>
                </div>
                <input
                  type="text"
                  maxLength={14}
                  value={student.lrn}
                  onChange={(e) => updateField('lrn', e.target.value.replace(/\D/g, ''))}
                  placeholder="12-digit LRN (e.g. 134171190015)"
                  className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm font-mono tracking-widest text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Education Level: JUNIOR or SENIOR HIGH */}
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Department Level <span className="text-emerald-400">*</span>
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => updateField('level', 'JUNIOR HIGH SCHOOL')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold tracking-wide transition-all border ${
                      student.level === 'JUNIOR HIGH SCHOOL'
                        ? 'bg-emerald-600/30 border-emerald-500 text-emerald-300 ring-1 ring-emerald-500'
                        : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    JUNIOR HIGH
                  </button>
                  <button
                    type="button"
                    onClick={() => updateField('level', 'SENIOR HIGH SCHOOL')}
                    className={`py-2 px-3 rounded-xl text-xs font-bold tracking-wide transition-all border ${
                      student.level === 'SENIOR HIGH SCHOOL'
                        ? 'bg-yellow-600/30 border-yellow-500 text-yellow-300 ring-1 ring-yellow-500'
                        : 'bg-slate-800/70 border-slate-700 text-slate-300 hover:bg-slate-800'
                    }`}
                  >
                    SENIOR HIGH
                  </button>
                </div>
              </div>

              {/* Senior High Strand / Track (if SHS) */}
              {student.level === 'SENIOR HIGH SCHOOL' && (
                <div className="md:col-span-2">
                  <label className="block text-xs font-semibold text-slate-300 mb-1">
                    Senior High Track / Strand (Optional)
                  </label>
                  <input
                    type="text"
                    value={student.trackStrand || ''}
                    onChange={(e) => updateField('trackStrand', e.target.value)}
                    placeholder="e.g. HUMSS, STEM, TVL, GAS, ABM"
                    className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
                  />
                </div>
              )}
            </div>
          </div>

          {/* Section 2: 1x1 Photo & Signature */}
          <div className="space-y-4 pt-3 border-t border-slate-800">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <Camera className="w-4 h-4" />
              2. 1x1 Photo &amp; Student Signature
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Photo Box */}
              <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-slate-700 overflow-hidden border-2 border-slate-600 flex items-center justify-center shrink-0">
                    {student.photoUrl ? (
                      <img
                        src={student.photoUrl}
                        alt="Student thumbnail"
                        className="w-full h-full object-cover"
                        style={{
                          transform: `scale(${student.photoScale || 1}) translate(${student.photoOffsetX || 0}%, ${student.photoOffsetY || 0}%)`,
                        }}
                      />
                    ) : (
                      <User className="w-6 h-6 text-slate-400" />
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">1x1 Photo</div>
                    <div className="text-xs text-slate-400">
                      {student.photoUrl ? 'Photo loaded' : 'Webcam or Upload'}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowPhotoModal(true)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Camera className="w-3.5 h-3.5" />
                  {student.photoUrl ? 'Adjust' : 'Set Photo'}
                </button>
              </div>

              {/* Signature Box */}
              <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-4 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-white overflow-hidden border-2 border-slate-600 flex items-center justify-center shrink-0 p-1">
                    {student.signatureUrl ? (
                      <img
                        src={student.signatureUrl}
                        alt="Signature thumbnail"
                        className="max-h-full max-w-full object-contain"
                      />
                    ) : (
                      <span className="font-script text-xs text-slate-400 font-bold">Sign</span>
                    )}
                  </div>
                  <div>
                    <div className="text-sm font-semibold text-white">Student Signature</div>
                    <div className="text-xs text-slate-400">
                      {student.signatureUrl ? 'Signature added' : 'Draw or Type'}
                    </div>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => setShowSignatureModal(true)}
                  className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <PenTool className="w-3.5 h-3.5" />
                  {student.signatureUrl ? 'Change' : 'Sign'}
                </button>
              </div>
            </div>
          </div>

          {/* Section 3: Birthday & Address (With Dropdown Selector) */}
          <div className="space-y-4 pt-3 border-t border-slate-800">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <Calendar className="w-4 h-4" />
              3. Birthday &amp; Residence Address
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:col-span-2">
                <label className="block text-xs font-semibold text-slate-300 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  Birth Date
                </label>
                <input
                  type="date"
                  value={student.birthDate}
                  onChange={(e) => updateField('birthDate', e.target.value)}
                  className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
                />
              </div>

              {/* Student Address with Philippine Address Dropdown Selector */}
              <div className="md:col-span-2">
                <PhilippineAddressSelector
                  label="Student Residence Address (Dropdown to prevent spelling errors)"
                  value={student.studentAddress}
                  onChange={(val) => updateField('studentAddress', val)}
                  required
                  placeholder="e.g. Brgy. Solon, Sultan Mastura, Maguindanao del Norte"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Guardian & Emergency Contact (With Dropdown Selector) */}
          <div className="space-y-4 pt-3 border-t border-slate-800">
            <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-400">
              <Phone className="w-4 h-4" />
              4. Guardian / Emergency Contact Information
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Guardian / Contact Person Full Name <span className="text-emerald-400">*</span>
                </label>
                <input
                  type="text"
                  value={student.emergencyContactName}
                  onChange={(e) => updateField('emergencyContactName', e.target.value)}
                  placeholder="e.g. Bimbing E. Asgar"
                  className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1">
                  Emergency Contact Phone Number <span className="text-emerald-400">*</span>
                </label>
                <input
                  type="text"
                  value={student.emergencyContactPhone}
                  onChange={(e) => updateField('emergencyContactPhone', e.target.value)}
                  placeholder="e.g. 0935-028-3612"
                  className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2 text-sm text-white font-mono focus:outline-none"
                />
              </div>

              {/* Guardian Address with Dropdown Selector */}
              <div className="md:col-span-2">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-xs font-semibold text-slate-300">
                    Guardian Residence Address
                  </span>
                  {student.studentAddress && (
                    <button
                      type="button"
                      onClick={() => updateField('emergencyContactAddress', student.studentAddress)}
                      className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold underline"
                    >
                      Copy Student Address
                    </button>
                  )}
                </div>
                <PhilippineAddressSelector
                  label="Guardian Address (Dropdown)"
                  value={student.emergencyContactAddress}
                  onChange={(val) => updateField('emergencyContactAddress', val)}
                  placeholder="e.g. Brgy. Solon, Sultan Mastura, Maguindanao del Norte"
                />
              </div>
            </div>
          </div>

          {/* Save to Registry Action */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
            <div className="text-xs text-slate-400">
              Live updates reflect on the card preview instantly.
            </div>
            <button
              type="button"
              onClick={onSaveToRegistry}
              className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-all shadow-md flex items-center gap-2 hover:shadow-emerald-500/20"
            >
              <Save className="w-4 h-4" />
              Save Student Record
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: SCHOOL ID CUSTOMIZATION (ADMIN ONLY - PROTECTED FROM STUDENTS)      */}
      {/* ========================================================================= */}
      {activeTab === 'customization' && (
        <div className="space-y-6 animate-fade-in">
          {/* Admin Header Banner with Lock Button */}
          <div className="p-3 bg-amber-950/40 border border-amber-600/50 rounded-xl flex items-center justify-between text-xs text-amber-200">
            <div className="flex items-center gap-2">
              <ShieldAlert className="w-4 h-4 text-amber-400 shrink-0" />
              <span>
                <strong>School Admin Mode:</strong> You are customizing the School ID Template. Changes here affect the school logo, card background, color schemes, cutting margins, and principal details.
              </span>
            </div>
            <button
              type="button"
              onClick={handleLockAdmin}
              className="px-2.5 py-1 bg-amber-800/60 hover:bg-amber-700 text-amber-100 rounded-lg text-[11px] font-semibold border border-amber-600 transition-colors flex items-center gap-1.5 shrink-0 ml-2"
            >
              <Lock className="w-3.5 h-3.5" />
              Lock for Students
            </button>
          </div>

          {/* 1. School Logo & Card Background (Plain White by Default) */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
                <ImageIcon className="w-4 h-4" />
                1. School Seal Logo &amp; Card Background
              </div>
              {student.backgroundUrl && (
                <button
                  type="button"
                  onClick={() => updateField('backgroundUrl', '')}
                  className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1"
                >
                  Reset to Plain White
                </button>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Custom School Seal / Logo Upload */}
              <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    School Seal / Official Logo
                  </span>
                  {student.schoolLogoUrl && (
                    <button
                      type="button"
                      onClick={() => updateField('schoolLogoUrl', '')}
                      className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Reset Seal
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <div className="w-16 h-16 rounded-full bg-slate-900 border border-slate-700 flex items-center justify-center p-1 overflow-hidden shrink-0">
                    <SchoolSeal size={56} customLogoUrl={student.schoolLogoUrl} />
                  </div>
                  <div className="space-y-1.5 flex-1">
                    <p className="text-[11px] text-slate-400">
                      Appears cleanly on the card back and school navigation.
                    </p>
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-lg cursor-pointer transition-colors">
                      <Upload className="w-3.5 h-3.5 text-emerald-400" />
                      Upload School Logo
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleLogoUpload}
                        className="hidden"
                      />
                    </label>
                  </div>
                </div>

                {/* Front Watermark Logo Toggle (Off by default as requested to avoid photo interference) */}
                <div className="pt-2 border-t border-slate-700/60">
                  <label className="flex items-center gap-2 cursor-pointer text-[11.5px] text-slate-300">
                    <input
                      type="checkbox"
                      checked={student.showFrontLogoWatermark ?? false}
                      onChange={(e) => updateField('showFrontLogoWatermark', e.target.checked)}
                      className="w-3.5 h-3.5 accent-amber-500 rounded"
                    />
                    <span>Show watermark on front (Off by default for clean background)</span>
                  </label>
                </div>
              </div>

              {/* Card Background: Plain White by Default, or Custom Upload */}
              <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-white uppercase tracking-wider">
                    Card Background {student.backgroundUrl ? '(Custom Upload)' : '(Plain White)'}
                  </span>
                  {student.backgroundUrl && (
                    <button
                      type="button"
                      onClick={() => updateField('backgroundUrl', '')}
                      className="text-[11px] text-rose-400 hover:text-rose-300 flex items-center gap-1"
                    >
                      <Trash2 className="w-3 h-3" /> Set Plain White
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-3">
                  <div
                    className="w-16 h-16 rounded-xl bg-white border border-slate-700 overflow-hidden shrink-0 bg-cover bg-center flex items-center justify-center text-slate-400 font-bold text-[10px]"
                    style={{
                      backgroundImage: student.backgroundUrl ? `url(${student.backgroundUrl})` : undefined,
                    }}
                  >
                    {!student.backgroundUrl && <span className="text-slate-500">WHITE</span>}
                  </div>

                  <div className="space-y-1.5 flex-1">
                    <p className="text-[11px] text-slate-400">
                      {student.backgroundUrl
                        ? 'Custom photo loaded. Fills continuously below the top header.'
                        : 'Currently Plain White (no interference with school logos).'}
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      <label className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-700 hover:bg-slate-600 text-white text-xs font-semibold rounded-lg cursor-pointer transition-colors">
                        <Upload className="w-3.5 h-3.5 text-sky-400" />
                        Upload Background
                        <input
                          type="file"
                          accept="image/*"
                          onChange={handleBackgroundUpload}
                          className="hidden"
                        />
                      </label>
                      {!student.backgroundUrl ? (
                        <button
                          type="button"
                          onClick={() => updateField('backgroundUrl', '/assets/aistudio/Done__1__32b471d1.jpg')}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg border border-slate-700"
                          title="Load Sulon NHS gate photo"
                        >
                          Gate Photo
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={() => updateField('backgroundUrl', '')}
                          className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-lg border border-slate-700"
                        >
                          Plain White
                        </button>
                      )}
                    </div>
                  </div>
                </div>

                {/* Opacity & Blur Sliders */}
                {student.backgroundUrl && (
                  <div className="pt-2 border-t border-slate-700/60 grid grid-cols-2 gap-3 text-[11px]">
                    <div>
                      <div className="flex justify-between text-slate-400 mb-1">
                        <span>Opacity</span>
                        <span className="font-mono">{Math.round((student.backgroundOpacity ?? 0.2) * 100)}%</span>
                      </div>
                      <input
                        type="range"
                        min="0.05"
                        max="0.8"
                        step="0.02"
                        value={student.backgroundOpacity ?? 0.2}
                        onChange={(e) => updateField('backgroundOpacity', parseFloat(e.target.value))}
                        className="w-full accent-amber-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                      />
                    </div>

                    <div>
                      <div className="flex justify-between text-slate-400 mb-1">
                        <span>Blur</span>
                        <span className="font-mono">{student.backgroundBlur ?? 0}px</span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max="10"
                        step="0.5"
                        value={student.backgroundBlur ?? 0}
                        onChange={(e) => updateField('backgroundBlur', parseFloat(e.target.value))}
                        className="w-full accent-sky-500 h-1 bg-slate-700 rounded-lg cursor-pointer"
                      />
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Cutting Allowance / Margin on All Sides */}
            <div className="bg-slate-800/40 border border-slate-700/80 rounded-xl p-3.5 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-3">
                <Scissors className="w-4 h-4 text-emerald-400" />
                <label className="flex items-center gap-2 cursor-pointer font-semibold text-slate-200">
                  <input
                    type="checkbox"
                    checked={student.includeCuttingMargin ?? true}
                    onChange={(e) => updateField('includeCuttingMargin', e.target.checked)}
                    className="w-4 h-4 accent-amber-500 rounded"
                  />
                  <span>Cutting Allowance Margin on all sides (with corner crop marks ┌ ┐ └ ┘)</span>
                </label>
              </div>

              {(student.includeCuttingMargin ?? true) && (
                <div className="flex items-center gap-2">
                  <span className="text-slate-400 text-[11px]">Allowance:</span>
                  {[2, 3, 4, 5].map((mm) => (
                    <button
                      key={mm}
                      type="button"
                      onClick={() => updateField('cuttingMarginMm', mm)}
                      className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        (student.cuttingMarginMm || 3) === mm
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-800 text-slate-400 hover:text-white'
                      }`}
                    >
                      {mm}mm
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* 2. Color Schemes for Junior & Senior High */}
          <div className="space-y-4 pt-3 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
                <Palette className="w-4 h-4" />
                2. Department Color Schemes (JHS &amp; SHS)
              </div>
              <button
                type="button"
                onClick={() => {
                  updateField('juniorHighColor', '#22c55e');
                  updateField('juniorHighStrokeColor', '#000000');
                  updateField('seniorHighColor', '#facc15');
                  updateField('seniorHighStrokeColor', '#000000');
                  updateField('headerBgStart', '#15803d');
                  updateField('headerBgEnd', '#4ade80');
                  updateField('schoolNameColor', '#fde047');
                }}
                className="text-[11px] text-slate-400 hover:text-white flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" /> Reset Colors
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Junior High Colors */}
              <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider">
                    Junior High Scheme
                  </span>
                  <span
                    className="text-[10px] font-bold px-2 py-0.5 rounded uppercase font-anton"
                    style={{
                      color: student.juniorHighColor || '#22c55e',
                      backgroundColor: '#000000',
                    }}
                  >
                    JUNIOR HIGH
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">
                      Text Fill Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={student.juniorHighColor || '#22c55e'}
                        onChange={(e) => updateField('juniorHighColor', e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={student.juniorHighColor || '#22c55e'}
                        onChange={(e) => updateField('juniorHighColor', e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono uppercase"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">
                      Stroke / Outline
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={student.juniorHighStrokeColor || '#000000'}
                        onChange={(e) => updateField('juniorHighStrokeColor', e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={student.juniorHighStrokeColor || '#000000'}
                        onChange={(e) => updateField('juniorHighStrokeColor', e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono uppercase"
                      />
                    </div>
                  </div>
                </div>

                {/* Presets */}
                <div className="pt-1 flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-400">Presets:</span>
                  <button
                    type="button"
                    onClick={() => {
                      updateField('juniorHighColor', '#22c55e');
                      updateField('juniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#22c55e] border border-white/40"
                    title="DepEd Green"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      updateField('juniorHighColor', '#38bdf8');
                      updateField('juniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#38bdf8] border border-white/40"
                    title="DepEd Sky Blue"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      updateField('juniorHighColor', '#f43f5e');
                      updateField('juniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#f43f5e] border border-white/40"
                    title="Crimson Red"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      updateField('juniorHighColor', '#a855f7');
                      updateField('juniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#a855f7] border border-white/40"
                    title="Violet Purple"
                  />
                </div>
              </div>

              {/* Senior High Colors */}
              <div className="bg-slate-800/50 border border-slate-700/80 rounded-xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-yellow-400 uppercase tracking-wider">
                    Senior High Scheme
                  </span>
                  <span
                    className="text-[10px] font-bold px-2 py-0.5 rounded uppercase font-anton"
                    style={{
                      color: student.seniorHighColor || '#facc15',
                      backgroundColor: '#000000',
                    }}
                  >
                    SENIOR HIGH
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">
                      Text Fill Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={student.seniorHighColor || '#facc15'}
                        onChange={(e) => updateField('seniorHighColor', e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={student.seniorHighColor || '#facc15'}
                        onChange={(e) => updateField('seniorHighColor', e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono uppercase"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[11px] font-medium text-slate-300 mb-1">
                      Stroke / Outline
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={student.seniorHighStrokeColor || '#000000'}
                        onChange={(e) => updateField('seniorHighStrokeColor', e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={student.seniorHighStrokeColor || '#000000'}
                        onChange={(e) => updateField('seniorHighStrokeColor', e.target.value)}
                        className="w-full bg-slate-800 border border-slate-700 rounded-lg px-2 py-1 text-xs text-white font-mono uppercase"
                      />
                    </div>
                  </div>
                </div>

                {/* Presets */}
                <div className="pt-1 flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-400">Presets:</span>
                  <button
                    type="button"
                    onClick={() => {
                      updateField('seniorHighColor', '#facc15');
                      updateField('seniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#facc15] border border-white/40"
                    title="Golden Yellow"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      updateField('seniorHighColor', '#fb923c');
                      updateField('seniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#fb923c] border border-white/40"
                    title="Amber Orange"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      updateField('seniorHighColor', '#ffffff');
                      updateField('seniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-white border border-white/40"
                    title="Crisp White"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      updateField('seniorHighColor', '#4ade80');
                      updateField('seniorHighStrokeColor', '#000000');
                    }}
                    className="w-5 h-5 rounded-full bg-[#4ade80] border border-white/40"
                    title="Lime Green"
                  />
                </div>
              </div>
            </div>

            {/* Top Header Colors */}
            <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-3.5 space-y-2">
              <div className="text-xs font-semibold text-slate-300">
                Card Header Gradient &amp; School Title Color
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Gradient Start</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={student.headerBgStart || '#15803d'}
                      onChange={(e) => updateField('headerBgStart', e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={student.headerBgStart || '#15803d'}
                      onChange={(e) => updateField('headerBgStart', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">Gradient End</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={student.headerBgEnd || '#4ade80'}
                      onChange={(e) => updateField('headerBgEnd', e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={student.headerBgEnd || '#4ade80'}
                      onChange={(e) => updateField('headerBgEnd', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] text-slate-400 mb-1">School Name Text Color</label>
                  <div className="flex items-center gap-2">
                    <input
                      type="color"
                      value={student.schoolNameColor || '#fde047'}
                      onChange={(e) => updateField('schoolNameColor', e.target.value)}
                      className="w-7 h-7 rounded cursor-pointer bg-transparent border-0"
                    />
                    <input
                      type="text"
                      value={student.schoolNameColor || '#fde047'}
                      onChange={(e) => updateField('schoolNameColor', e.target.value)}
                      className="w-full bg-slate-800 border border-slate-700 rounded px-2 py-1 text-xs text-white font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* 3. School Administrative & Principal Details */}
          <div className="space-y-4 pt-3 border-t border-slate-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-amber-400">
                <School className="w-4 h-4" />
                3. School Headers &amp; Principal Designation
              </div>
              <button
                type="button"
                onClick={() => {
                  onChange({
                    ...student,
                    ...DEFAULT_SCHOOL_CONFIG,
                  });
                }}
                className="text-[11px] text-slate-400 hover:text-white underline"
              >
                Reset School Config
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 bg-slate-800/40 p-4 rounded-xl border border-slate-700/60">
              <div className="md:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  School Name
                </label>
                <input
                  type="text"
                  value={student.schoolName}
                  onChange={(e) => updateField('schoolName', e.target.value.toUpperCase())}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white uppercase font-bold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  School ID Number
                </label>
                <input
                  type="text"
                  value={student.schoolIdNumber}
                  onChange={(e) => updateField('schoolIdNumber', e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  School Address
                </label>
                <input
                  type="text"
                  value={student.schoolAddress}
                  onChange={(e) => updateField('schoolAddress', e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Division Header
                </label>
                <input
                  type="text"
                  value={student.divisionHeader}
                  onChange={(e) => updateField('divisionHeader', e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Principal Name (19px Bold)
                </label>
                <input
                  type="text"
                  value={student.principalName}
                  onChange={(e) => updateField('principalName', e.target.value.toUpperCase())}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white uppercase font-bold"
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                  Principal Designation / Title
                </label>
                <input
                  type="text"
                  value={student.principalTitle}
                  onChange={(e) => updateField('principalTitle', e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                />
              </div>

              {/* Principal Signature Graphic Toggle (Removed by default) */}
              <div className="md:col-span-2 pt-2 border-t border-slate-700/60 flex items-center justify-between text-xs">
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={student.showPrincipalSignature ?? false}
                    onChange={(e) => updateField('showPrincipalSignature', e.target.checked)}
                    className="w-4 h-4 accent-amber-500 rounded"
                  />
                  <span>Include Principal Signature graphic (Removed by default)</span>
                </label>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Admin Unlock Modal Dialog */}
      {showUnlockModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/50 rounded-2xl max-w-md w-full p-6 shadow-2xl text-white space-y-4 animate-scale-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-oswald uppercase">
                  School Administrator Access
                </h3>
                <p className="text-xs text-slate-400">
                  ID Customization &amp; Student Registry are restricted to authorized school staff.
                </p>
              </div>
            </div>

            <form onSubmit={handleVerifyPin} className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Enter Admin PIN Code
                </label>
                <input
                  type="password"
                  value={adminPinInput}
                  onChange={(e) => setAdminPinInput(e.target.value)}
                  placeholder="••••••"
                  autoFocus
                  className="w-full bg-slate-800 border border-slate-700 focus:border-amber-500 rounded-xl px-4 py-2.5 text-sm font-mono tracking-widest text-center text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
                {pinError && (
                  <p className="text-xs text-rose-400 mt-1.5 font-medium">{pinError}</p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowUnlockModal(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-300 hover:text-white rounded-lg bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-black bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-md"
                >
                  Unlock
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modals for Photo and Signature */}
      {showPhotoModal && (
        <PhotoEditorModal
          initialPhotoUrl={student.photoUrl}
          initialScale={student.photoScale || 1}
          initialOffsetX={student.photoOffsetX || 0}
          initialOffsetY={student.photoOffsetY || 0}
          onSave={(photoUrl, scale, offsetX, offsetY) => {
            onChange({
              ...student,
              photoUrl,
              photoScale: scale,
              photoOffsetX: offsetX,
              photoOffsetY: offsetY,
              updatedAt: new Date().toISOString(),
            });
          }}
          onClose={() => setShowPhotoModal(false)}
        />
      )}

      {showSignatureModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-sm flex items-center justify-center p-4">
          <SignaturePad
            initialSignature={student.signatureUrl}
            studentName={student.fullName}
            onSave={(signatureDataUrl) => {
              updateField('signatureUrl', signatureDataUrl);
            }}
            onClose={() => setShowSignatureModal(false)}
          />
        </div>
      )}
    </div>
  );
};
