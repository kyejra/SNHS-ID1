import React, { useState } from 'react';
import { StudentRecord } from '../types/student';
import { formatBirthDateDisplay, DEFAULT_SCHOOL_CONFIG } from '../data/sampleStudents';
import {
  FileSpreadsheet,
  Download,
  Upload,
  Search,
  CheckSquare,
  Square,
  Trash2,
  Edit,
  Copy,
  Printer,
  FileDown,
  Sparkles,
} from 'lucide-react';
import * as XLSX from 'xlsx';

interface SpreadsheetManagerProps {
  students: StudentRecord[];
  activeStudentId: string;
  onSelectStudent: (student: StudentRecord) => void;
  onUpdateStudents: (students: StudentRecord[]) => void;
  onBatchPrint: (selectedStudents: StudentRecord[]) => void;
}

export const SpreadsheetManager: React.FC<SpreadsheetManagerProps> = ({
  students,
  activeStudentId,
  onSelectStudent,
  onUpdateStudents,
  onBatchPrint,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState<string>('ALL');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Filter students
  const filteredStudents = students.filter((s) => {
    const matchesSearch =
      (s.fullName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (s.lrn || '').includes(searchTerm) ||
      (s.emergencyContactName || '').toLowerCase().includes(searchTerm.toLowerCase());
    const matchesLevel =
      levelFilter === 'ALL' || s.level === levelFilter;
    return matchesSearch && matchesLevel;
  });

  // Toggle selection
  const toggleSelectOne = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredStudents.length && filteredStudents.length > 0) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredStudents.map((s) => s.id)));
    }
  };

  // Export to Excel (.xlsx)
  const exportToExcel = (onlySelected = false) => {
    const targetList = onlySelected && selectedIds.size > 0
      ? students.filter((s) => selectedIds.has(s.id))
      : students;

    const dataRows = targetList.map((s, idx) => ({
      'No.': idx + 1,
      'LRN (Learner Reference No.)': s.lrn,
      'Student Full Name': s.fullName,
      'Department / Level': s.level,
      'Track / Strand': s.trackStrand || 'N/A',
      'Birth Date': s.birthDate,
      'Formatted Birth Date': formatBirthDateDisplay(s.birthDate),
      'Student Address': s.studentAddress,
      'Emergency Contact Name': s.emergencyContactName,
      'Emergency Contact Address': s.emergencyContactAddress,
      'Emergency Phone Number': s.emergencyContactPhone,
      'School Name': s.schoolName,
      'School ID': s.schoolIdNumber,
      'Principal': s.principalName,
      'Date Registered': s.createdAt ? new Date(s.createdAt).toLocaleDateString() : 'N/A',
    }));

    const worksheet = XLSX.utils.json_to_sheet(dataRows);

    // Set column widths
    worksheet['!cols'] = [
      { wch: 5 },  // No.
      { wch: 18 }, // LRN
      { wch: 25 }, // Full Name
      { wch: 20 }, // Level
      { wch: 14 }, // Strand
      { wch: 14 }, // Birth Date
      { wch: 18 }, // Formatted
      { wch: 35 }, // Address
      { wch: 22 }, // Emergency Contact
      { wch: 35 }, // Emergency Address
      { wch: 16 }, // Phone
      { wch: 28 }, // School Name
      { wch: 12 }, // School ID
      { wch: 16 }, // Principal
      { wch: 14 }, // Date
    ];

    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Sulon_NHS_Students');
    XLSX.writeFile(workbook, `Sulon_NHS_Student_ID_Registry_${new Date().toISOString().slice(0, 10)}.xlsx`);
  };

  // Export to CSV
  const exportToCsv = () => {
    const targetList = selectedIds.size > 0
      ? students.filter((s) => selectedIds.has(s.id))
      : students;

    const headers = [
      'LRN',
      'Full Name',
      'Level',
      'Track Strand',
      'Birth Date',
      'Student Address',
      'Emergency Contact Person',
      'Emergency Contact Address',
      'Emergency Phone Number',
      'School Name',
      'School ID Number',
    ];

    const escapeCsv = (str: string) => `"${(str || '').replace(/"/g, '""')}"`;

    const rows = targetList.map((s) => [
      escapeCsv(s.lrn),
      escapeCsv(s.fullName),
      escapeCsv(s.level),
      escapeCsv(s.trackStrand || ''),
      escapeCsv(s.birthDate),
      escapeCsv(s.studentAddress),
      escapeCsv(s.emergencyContactName),
      escapeCsv(s.emergencyContactAddress),
      escapeCsv(s.emergencyContactPhone),
      escapeCsv(s.schoolName),
      escapeCsv(s.schoolIdNumber),
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `Sulon_NHS_Students_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
  };

  // Download Blank CSV/Excel Template for bulk import
  const downloadTemplate = () => {
    const templateRows = [
      {
        'LRN': '134171190015',
        'Full Name': 'TONGGAL E. ASGAR',
        'Level': 'JUNIOR HIGH SCHOOL',
        'Track Strand': '',
        'Birth Date': '2014-07-18',
        'Student Address': 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
        'Emergency Contact Person': 'Bimbing E. Asgar',
        'Emergency Contact Address': 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
        'Emergency Phone Number': '0935-028-3612',
      },
      {
        'LRN': '134234150046',
        'Full Name': 'SAHJID T. KASAN',
        'Level': 'SENIOR HIGH SCHOOL',
        'Track Strand': 'HUMSS',
        'Birth Date': '2010-09-29',
        'Student Address': 'Brgy. Dagurongan, Sultan Mastura, Maguindanao del Norte',
        'Emergency Contact Person': 'Eden Tariwasay',
        'Emergency Contact Address': 'Brgy. Dagurongan, Sultan Mastura, Maguindanao del Norte',
        'Emergency Phone Number': '0997-497-2215',
      },
    ];

    const worksheet = XLSX.utils.json_to_sheet(templateRows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Students_Template');
    XLSX.writeFile(workbook, 'Sulon_NHS_Import_Template.xlsx');
  };

  // Import Spreadsheet file (Excel or CSV)
  const handleImportSpreadsheet = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const buffer = event.target?.result;
        const workbook = XLSX.read(buffer, { type: 'binary' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json<any>(worksheet);

        if (!jsonData || jsonData.length === 0) {
          alert('Spreadsheet appears to be empty.');
          return;
        }

        const importedList: StudentRecord[] = jsonData.map((row: any, i: number) => {
          // Normalize column names
          const lrn = row['LRN'] || row['Learner Reference No.'] || row['lrn'] || '';
          const fullName = (row['Full Name'] || row['Student Full Name'] || row['Name'] || row['name'] || '').toUpperCase();
          const levelRaw = (row['Level'] || row['Department'] || row['Grade'] || '').toUpperCase();
          const level = levelRaw.includes('SENIOR') ? 'SENIOR HIGH SCHOOL' : 'JUNIOR HIGH SCHOOL';
          const birthDate = row['Birth Date'] || row['birthDate'] || row['DOB'] || '';
          const studentAddress = row['Student Address'] || row['Address'] || 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte';
          const emergencyName = row['Emergency Contact Person'] || row['Emergency Contact Name'] || row['Contact Person'] || '';
          const emergencyAddress = row['Emergency Contact Address'] || row['Emergency Address'] || studentAddress;
          const emergencyPhone = row['Emergency Phone Number'] || row['Emergency Phone'] || row['Phone'] || '';

          return {
            ...DEFAULT_SCHOOL_CONFIG,
            id: `imported-${Date.now()}-${i}`,
            lrn: String(lrn).replace(/\D/g, ''),
            fullName,
            level,
            trackStrand: row['Track Strand'] || row['Strand'] || '',
            birthDate: String(birthDate),
            studentAddress: String(studentAddress),
            emergencyContactName: String(emergencyName),
            emergencyContactAddress: String(emergencyAddress),
            emergencyContactPhone: String(emergencyPhone),
            photoUrl: '',
            signatureUrl: '',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
        });

        onUpdateStudents([...importedList, ...students]);
        alert(`Successfully imported ${importedList.length} student records from spreadsheet!`);
      } catch (err) {
        console.error('Import error:', err);
        alert('Failed to parse spreadsheet file. Please verify format.');
      }
    };
    reader.readAsBinaryString(file);
  };

  // Row operations
  const duplicateStudent = (s: StudentRecord) => {
    const copy: StudentRecord = {
      ...s,
      id: `student-${Date.now()}`,
      fullName: `${s.fullName} (COPY)`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    onUpdateStudents([copy, ...students]);
  };

  const deleteStudent = (id: string) => {
    if (confirm('Are you sure you want to remove this student record?')) {
      onUpdateStudents(students.filter((s) => s.id !== id));
      selectedIds.delete(id);
      setSelectedIds(new Set(selectedIds));
    }
  };

  const deleteSelected = () => {
    if (confirm(`Delete ${selectedIds.size} selected student records?`)) {
      onUpdateStudents(students.filter((s) => !selectedIds.has(s.id)));
      setSelectedIds(new Set());
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 text-white shadow-xl">
      {/* Top Header & Export Buttons */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-4 border-b border-slate-800">
        <div>
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
            Student Spreadsheet Registry ({students.length})
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Auto-export records to Excel (.xlsx) / CSV or batch import student rosters
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Download Template */}
          <button
            type="button"
            onClick={downloadTemplate}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
            title="Download formatted Excel template for importing"
          >
            <FileDown className="w-3.5 h-3.5 text-slate-400" />
            Template
          </button>

          {/* Import Spreadsheet */}
          <label className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors cursor-pointer flex items-center gap-1.5">
            <Upload className="w-3.5 h-3.5 text-sky-400" />
            Import Excel/CSV
            <input
              type="file"
              accept=".xlsx,.xls,.csv"
              onChange={handleImportSpreadsheet}
              className="hidden"
            />
          </label>

          {/* Export to CSV */}
          <button
            type="button"
            onClick={exportToCsv}
            className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-lg border border-slate-700 transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            Export CSV
          </button>

          {/* Export to Excel (.xlsx) */}
          <button
            type="button"
            onClick={() => exportToExcel(false)}
            className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg shadow-sm transition-colors flex items-center gap-1.5"
          >
            <Download className="w-4 h-4" />
            Export to Excel (.xlsx)
          </button>
        </div>
      </div>

      {/* Filter & Search Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Search */}
        <div className="relative flex-1 min-w-[220px]">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by student name, LRN, emergency contact..."
            className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl pl-9 pr-3 py-2 text-xs text-white focus:outline-none"
          />
        </div>

        {/* Level Filter Tabs */}
        <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg">
          <button
            type="button"
            onClick={() => setLevelFilter('ALL')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              levelFilter === 'ALL' ? 'bg-slate-700 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            All ({students.length})
          </button>
          <button
            type="button"
            onClick={() => setLevelFilter('JUNIOR HIGH SCHOOL')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              levelFilter === 'JUNIOR HIGH SCHOOL' ? 'bg-emerald-700 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Junior High
          </button>
          <button
            type="button"
            onClick={() => setLevelFilter('SENIOR HIGH SCHOOL')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              levelFilter === 'SENIOR HIGH SCHOOL' ? 'bg-yellow-700 text-white font-semibold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Senior High
          </button>
        </div>

        {/* Batch selection controls */}
        {selectedIds.size > 0 && (
          <div className="flex items-center gap-2 bg-emerald-950/60 border border-emerald-800 px-3 py-1.5 rounded-lg text-xs">
            <span className="font-semibold text-emerald-300">
              {selectedIds.size} selected
            </span>
            <button
              type="button"
              onClick={() => onBatchPrint(students.filter((s) => selectedIds.has(s.id)))}
              className="px-2 py-0.5 bg-emerald-700 hover:bg-emerald-600 text-white rounded font-medium flex items-center gap-1"
            >
              <Printer className="w-3 h-3" /> Print Selected
            </button>
            <button
              type="button"
              onClick={() => exportToExcel(true)}
              className="px-2 py-0.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-medium flex items-center gap-1"
            >
              <Download className="w-3 h-3" /> Export Selected
            </button>
            <button
              type="button"
              onClick={deleteSelected}
              className="px-2 py-0.5 bg-rose-900/80 hover:bg-rose-800 text-rose-200 rounded font-medium flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" /> Delete
            </button>
          </div>
        )}
      </div>

      {/* Spreadsheet Data Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-left text-xs text-slate-300">
          <thead className="bg-slate-800/80 text-slate-400 uppercase font-bold tracking-wider text-[11px] border-b border-slate-800">
            <tr>
              <th className="p-3 w-10">
                <button
                  type="button"
                  onClick={toggleSelectAll}
                  className="text-slate-400 hover:text-white"
                >
                  {selectedIds.size === filteredStudents.length && filteredStudents.length > 0 ? (
                    <CheckSquare className="w-4 h-4 text-emerald-400" />
                  ) : (
                    <Square className="w-4 h-4" />
                  )}
                </button>
              </th>
              <th className="p-3">Photo</th>
              <th className="p-3">LRN</th>
              <th className="p-3">Student Name</th>
              <th className="p-3">Department</th>
              <th className="p-3">Birth Date</th>
              <th className="p-3">Emergency Contact</th>
              <th className="p-3">Address</th>
              <th className="p-3 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-sans">
            {filteredStudents.length === 0 ? (
              <tr>
                <td colSpan={9} className="p-8 text-center text-slate-400">
                  No matching student records found.
                </td>
              </tr>
            ) : (
              filteredStudents.map((s) => {
                const isActive = s.id === activeStudentId;
                const isSelected = selectedIds.has(s.id);

                return (
                  <tr
                    key={s.id}
                    className={`transition-colors hover:bg-slate-800/40 ${
                      isActive ? 'bg-emerald-950/20 border-l-2 border-emerald-500' : ''
                    } ${isSelected ? 'bg-slate-800/30' : ''}`}
                  >
                    <td className="p-3">
                      <button
                        type="button"
                        onClick={() => toggleSelectOne(s.id)}
                        className="text-slate-400 hover:text-white"
                      >
                        {isSelected ? (
                          <CheckSquare className="w-4 h-4 text-emerald-400" />
                        ) : (
                          <Square className="w-4 h-4" />
                        )}
                      </button>
                    </td>

                    {/* Photo thumbnail */}
                    <td className="p-3">
                      <div className="w-8 h-8 rounded-lg overflow-hidden bg-slate-700 border border-slate-600 flex items-center justify-center">
                        {s.photoUrl ? (
                          <img
                            src={s.photoUrl}
                            alt=""
                            className="w-full h-full object-cover"
                            style={{
                              transform: `scale(${s.photoScale || 1}) translate(${s.photoOffsetX || 0}%, ${s.photoOffsetY || 0}%)`,
                            }}
                          />
                        ) : (
                          <span className="text-[9px] text-slate-400 font-bold">1x1</span>
                        )}
                      </div>
                    </td>

                    {/* LRN */}
                    <td className="p-3 font-mono font-bold tracking-wider text-white">
                      {s.lrn || '-'}
                    </td>

                    {/* Student Name */}
                    <td className="p-3 font-semibold text-white">
                      <button
                        type="button"
                        onClick={() => onSelectStudent(s)}
                        className="hover:text-emerald-400 transition-colors text-left"
                      >
                        {s.fullName || 'UNNAMED'}
                      </button>
                    </td>

                    {/* Level */}
                    <td className="p-3">
                      <span
                        className={`text-[10px] font-bold px-2 py-0.5 rounded ${
                          s.level === 'SENIOR HIGH SCHOOL'
                            ? 'bg-yellow-950/80 text-yellow-300 border border-yellow-800'
                            : 'bg-emerald-950/80 text-emerald-300 border border-emerald-800'
                        }`}
                      >
                        {s.level === 'SENIOR HIGH SCHOOL' ? 'SENIOR HIGH' : 'JUNIOR HIGH'}
                      </span>
                    </td>

                    {/* Birth Date */}
                    <td className="p-3 font-medium text-slate-300 whitespace-nowrap">
                      {formatBirthDateDisplay(s.birthDate)}
                    </td>

                    {/* Emergency Contact */}
                    <td className="p-3">
                      <div className="font-medium text-white">{s.emergencyContactName || '-'}</div>
                      <div className="text-[11px] text-slate-400 font-mono">{s.emergencyContactPhone || '-'}</div>
                    </td>

                    {/* Address */}
                    <td className="p-3 text-slate-400 max-w-[200px] truncate" title={s.studentAddress}>
                      {s.studentAddress || '-'}
                    </td>

                    {/* Actions */}
                    <td className="p-3 text-right whitespace-nowrap">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          type="button"
                          onClick={() => onSelectStudent(s)}
                          className="p-1.5 rounded-lg bg-emerald-950/50 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800/60 transition-colors"
                          title="Open & Edit in ID Designer"
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => duplicateStudent(s)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
                          title="Duplicate Record"
                        >
                          <Copy className="w-3.5 h-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => deleteStudent(s.id)}
                          className="p-1.5 rounded-lg bg-slate-800 hover:bg-rose-900/50 text-slate-400 hover:text-rose-300 transition-colors"
                          title="Delete Record"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
