import React from 'react';

interface PrincipalSignatureProps {
  customSignatureUrl?: string;
  name?: string;
  title?: string;
  className?: string;
  showSignature?: boolean; // Controlled by user request to remove principal signature
}

export const PrincipalSignature: React.FC<PrincipalSignatureProps> = ({
  customSignatureUrl,
  name = 'LUNA L. SLA',
  title = 'Principal I',
  className = '',
  showSignature = false, // Default is false as requested
}) => {
  return (
    <div className={`flex flex-col items-center justify-center text-center select-none ${className}`}>
      {/* Signature Graphic - Only render if showSignature is true */}
      {showSignature && (
        <div className="h-10 w-36 flex items-center justify-center relative -mb-1">
          {customSignatureUrl ? (
            <img
              src={customSignatureUrl}
              alt="Principal Signature"
              className="max-h-11 max-w-full object-contain"
            />
          ) : (
            <svg viewBox="0 0 160 50" className="w-full h-full text-black stroke-current fill-none">
              <path
                d="M 22 34 C 28 22, 34 10, 42 6 C 47 4, 49 14, 52 28 C 55 38, 56 42, 60 40 C 65 37, 72 24, 76 18 C 79 14, 82 22, 85 34 C 88 42, 92 44, 98 38 C 104 32, 114 16, 118 12 C 122 8, 120 20, 118 32 C 117 38, 126 36, 134 32"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M 38 42 L 88 8 L 96 44 L 112 18"
                strokeWidth="1.8"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M 28 28 L 138 24"
                strokeWidth="1.4"
                strokeLinecap="round"
              />
            </svg>
          )}
        </div>
      )}

      {/* Name - Adjusted larger as requested ("adjust the size of Principal name it is too small") */}
      <div className="font-oswald font-black text-[18px] md:text-[19px] tracking-wider uppercase text-black leading-tight">
        {name}
      </div>

      {/* Designation / Title */}
      <div className="text-[12.5px] font-bold italic text-slate-800 tracking-wide font-sans-ui mt-0.5">
        {title}
      </div>
    </div>
  );
};
