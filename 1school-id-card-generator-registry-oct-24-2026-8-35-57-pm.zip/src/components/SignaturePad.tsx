import React, { useRef, useState, useEffect, useCallback } from 'react';
import { PenTool, RotateCcw, Upload, Type, Check, Trash2, Sliders } from 'lucide-react';

interface SignaturePadProps {
  initialSignature?: string;
  studentName?: string;
  onSave: (signatureDataUrl: string) => void;
  onClose?: () => void;
}

export const SignaturePad: React.FC<SignaturePadProps> = ({
  initialSignature = '',
  studentName = '',
  onSave,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'draw' | 'type' | 'upload'>('draw');
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [hasDrawn, setHasDrawn] = useState(false);
  const [penColor, setPenColor] = useState<string>('#000000');
  const [penWidth, setPenWidth] = useState<number>(2.5);

  // Type signature options
  const [typedName, setTypedName] = useState(studentName);
  const [selectedFont, setSelectedFont] = useState<'font-script' | 'font-brush' | 'font-caveat'>('font-script');

  // Initialize canvas
  const setupCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // High DPI scaling
    const rect = canvas.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 2;
    canvas.width = rect.width * dpr;
    canvas.height = rect.height * dpr;
    ctx.scale(dpr, dpr);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    // If initial signature exists, load it
    if (initialSignature && activeTab === 'draw') {
      const img = new Image();
      img.onload = () => {
        ctx.clearRect(0, 0, rect.width, rect.height);
        ctx.drawImage(img, 0, 0, rect.width, rect.height);
        setHasDrawn(true);
      };
      img.src = initialSignature;
    }
  }, [initialSignature, activeTab]);

  useEffect(() => {
    setupCanvas();
  }, [setupCanvas]);

  // Drawing event handlers
  const startDrawing = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    setIsDrawing(true);
    setHasDrawn(true);

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.beginPath();
    ctx.moveTo(x, y);
    ctx.strokeStyle = penColor;
    ctx.lineWidth = penWidth;
  };

  const draw = (e: React.MouseEvent<HTMLCanvasElement> | React.TouchEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : e.clientY;
    const x = clientX - rect.left;
    const y = clientY - rect.top;

    ctx.lineTo(x, y);
    ctx.stroke();
  };

  const stopDrawing = () => {
    if (!isDrawing) return;
    setIsDrawing(false);
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.closePath();
  };

  const clearCanvas = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const rect = canvas.getBoundingClientRect();
    ctx.clearRect(0, 0, rect.width, rect.height);
    setHasDrawn(false);
  };

  // Convert typed text to PNG Data URL
  const generateTypedSignatureDataUrl = (): string => {
    const tempCanvas = document.createElement('canvas');
    tempCanvas.width = 400;
    tempCanvas.height = 120;
    const ctx = tempCanvas.getContext('2d');
    if (!ctx) return '';

    ctx.clearRect(0, 0, tempCanvas.width, tempCanvas.height);
    ctx.fillStyle = penColor;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    let fontSpec = '48px "Dancing Script", cursive';
    if (selectedFont === 'font-brush') {
      fontSpec = '52px "Alex Brush", cursive';
    } else if (selectedFont === 'font-caveat') {
      fontSpec = '46px "Caveat", cursive';
    }

    ctx.font = fontSpec;
    ctx.fillText(typedName || studentName || 'Signature', 200, 60);

    return tempCanvas.toDataURL('image/png');
  };

  // Handle signature image upload with white background transparency
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        // Create an offscreen canvas to remove white background
        const offCanvas = document.createElement('canvas');
        offCanvas.width = img.width;
        offCanvas.height = img.height;
        const offCtx = offCanvas.getContext('2d');
        if (!offCtx) return;

        offCtx.drawImage(img, 0, 0);
        const imgData = offCtx.getImageData(0, 0, offCanvas.width, offCanvas.height);
        const data = imgData.data;

        // Auto-thresholding: pixels close to white become transparent
        for (let i = 0; i < data.length; i += 4) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const brightness = (r * 0.299 + g * 0.587 + b * 0.114);

          if (brightness > 210) {
            data[i + 3] = 0; // Transparent
          } else {
            // Darken ink
            data[i] = 20;
            data[i + 1] = 20;
            data[i + 2] = 25;
            data[i + 3] = Math.min(255, 255 - brightness);
          }
        }

        offCtx.putImageData(imgData, 0, 0);
        const processedUrl = offCanvas.toDataURL('image/png');
        onSave(processedUrl);
        if (onClose) onClose();
      };
      img.src = event.target?.result as string;
    };
    reader.readAsDataURL(file);
  };

  const handleApply = () => {
    if (activeTab === 'draw') {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const dataUrl = canvas.toDataURL('image/png');
      onSave(dataUrl);
    } else if (activeTab === 'type') {
      const dataUrl = generateTypedSignatureDataUrl();
      onSave(dataUrl);
    }
    if (onClose) onClose();
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 text-white max-w-lg w-full shadow-2xl">
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <PenTool className="w-5 h-5 text-emerald-400" />
          <h3 className="font-semibold text-base text-white">Student Signature</h3>
        </div>
        <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg">
          <button
            type="button"
            onClick={() => setActiveTab('draw')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'draw' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Draw
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('type')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'type' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Type Script
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('upload')}
            className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
              activeTab === 'upload' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Upload
          </button>
        </div>
      </div>

      {/* Main Body */}
      <div className="py-4">
        {/* Draw Mode */}
        {activeTab === 'draw' && (
          <div className="space-y-3">
            <div className="relative bg-white rounded-xl overflow-hidden border-2 border-slate-700 shadow-inner">
              <canvas
                ref={canvasRef}
                onMouseDown={startDrawing}
                onMouseMove={draw}
                onMouseUp={stopDrawing}
                onMouseLeave={stopDrawing}
                onTouchStart={startDrawing}
                onTouchMove={draw}
                onTouchEnd={stopDrawing}
                className="w-full h-40 cursor-crosshair touch-none"
              />
              {/* Subtle signature guideline */}
              <div className="absolute bottom-6 left-6 right-6 border-b border-dashed border-slate-300 pointer-events-none flex justify-between text-[10px] text-slate-400 font-sans">
                <span>Sign above line</span>
                <span>Sulon NHS</span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between text-xs text-slate-300 pt-1">
              {/* Pen Color */}
              <div className="flex items-center gap-2">
                <span className="text-slate-400">Ink:</span>
                <button
                  type="button"
                  onClick={() => setPenColor('#000000')}
                  className={`w-6 h-6 rounded-full bg-black border-2 transition-transform ${
                    penColor === '#000000' ? 'scale-110 border-emerald-400' : 'border-slate-600'
                  }`}
                  title="Black Ink"
                />
                <button
                  type="button"
                  onClick={() => setPenColor('#1e3a8a')}
                  className={`w-6 h-6 rounded-full bg-blue-900 border-2 transition-transform ${
                    penColor === '#1e3a8a' ? 'scale-110 border-emerald-400' : 'border-slate-600'
                  }`}
                  title="Navy Blue Ink"
                />
              </div>

              {/* Pen Width */}
              <div className="flex items-center gap-2">
                <Sliders className="w-3.5 h-3.5 text-slate-400" />
                <button
                  type="button"
                  onClick={() => setPenWidth(1.5)}
                  className={`px-2 py-0.5 rounded text-[11px] ${
                    penWidth === 1.5 ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Fine
                </button>
                <button
                  type="button"
                  onClick={() => setPenWidth(2.5)}
                  className={`px-2 py-0.5 rounded text-[11px] ${
                    penWidth === 2.5 ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Medium
                </button>
                <button
                  type="button"
                  onClick={() => setPenWidth(4)}
                  className={`px-2 py-0.5 rounded text-[11px] ${
                    penWidth === 4 ? 'bg-slate-700 text-white font-bold' : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Thick
                </button>
              </div>

              {/* Clear */}
              <button
                type="button"
                onClick={clearCanvas}
                className="flex items-center gap-1 text-rose-400 hover:text-rose-300 transition-colors px-2 py-1 rounded bg-rose-950/40 border border-rose-800/50"
              >
                <RotateCcw className="w-3 h-3" />
                Clear
              </button>
            </div>
          </div>
        )}

        {/* Type Mode */}
        {activeTab === 'type' && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1">
                Student Name / Script Text
              </label>
              <input
                type="text"
                value={typedName}
                onChange={(e) => setTypedName(e.target.value)}
                placeholder="e.g. Tonggal Asgar"
                className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white text-sm focus:outline-none focus:border-emerald-500"
              />
            </div>

            {/* Script Font Selection */}
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setSelectedFont('font-script')}
                className={`p-3 rounded-lg border text-center transition-all bg-white text-black ${
                  selectedFont === 'font-script' ? 'border-emerald-500 ring-2 ring-emerald-500/50' : 'border-slate-300'
                }`}
              >
                <div className="font-script text-xl leading-none">
                  {typedName || 'Dancing Script'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-sans">Casual Script</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedFont('font-brush')}
                className={`p-3 rounded-lg border text-center transition-all bg-white text-black ${
                  selectedFont === 'font-brush' ? 'border-emerald-500 ring-2 ring-emerald-500/50' : 'border-slate-300'
                }`}
              >
                <div className="font-brush text-2xl leading-none">
                  {typedName || 'Alex Brush'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-sans">Elegant Calligraphy</div>
              </button>

              <button
                type="button"
                onClick={() => setSelectedFont('font-caveat')}
                className={`p-3 rounded-lg border text-center transition-all bg-white text-black ${
                  selectedFont === 'font-caveat' ? 'border-emerald-500 ring-2 ring-emerald-500/50' : 'border-slate-300'
                }`}
              >
                <div className="font-sans font-semibold text-lg leading-none" style={{ fontFamily: 'Caveat, cursive' }}>
                  {typedName || 'Caveat Hand'}
                </div>
                <div className="text-[10px] text-slate-500 mt-1 font-sans">Natural Handwriting</div>
              </button>
            </div>
          </div>
        )}

        {/* Upload Mode */}
        {activeTab === 'upload' && (
          <div className="space-y-3">
            <div className="border-2 border-dashed border-slate-700 rounded-xl p-6 text-center hover:border-emerald-500/60 transition-colors bg-slate-800/40">
              <Upload className="w-10 h-10 text-emerald-400 mx-auto mb-2" />
              <p className="text-sm font-medium text-slate-200">
                Upload scanned or photographed signature
              </p>
              <p className="text-xs text-slate-400 mt-1">
                White backgrounds are automatically cleared and transparentized
              </p>
              <label className="mt-4 inline-block px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg cursor-pointer transition-colors shadow-sm">
                Choose Image File
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        )}
      </div>

      {/* Footer Actions */}
      <div className="flex items-center justify-between pt-3 border-t border-slate-800">
        {initialSignature ? (
          <button
            type="button"
            onClick={() => {
              onSave('');
              if (onClose) onClose();
            }}
            className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-rose-400 transition-colors"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Remove Signature
          </button>
        ) : <div />}

        <div className="flex items-center gap-2">
          {onClose && (
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-300 hover:text-white transition-colors"
            >
              Cancel
            </button>
          )}
          <button
            type="button"
            onClick={handleApply}
            className="flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg transition-colors shadow-sm"
          >
            <Check className="w-4 h-4" />
            Apply Signature
          </button>
        </div>
      </div>
    </div>
  );
};
