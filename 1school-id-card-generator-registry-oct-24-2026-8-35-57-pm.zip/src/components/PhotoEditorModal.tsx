import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Camera, Upload, ZoomIn, ZoomOut, Move, Check, X, RefreshCw, AlertCircle, SwitchCamera } from 'lucide-react';

interface PhotoEditorModalProps {
  initialPhotoUrl?: string;
  initialScale?: number;
  initialOffsetX?: number;
  initialOffsetY?: number;
  onSave: (photoUrl: string, scale: number, offsetX: number, offsetY: number) => void;
  onClose: () => void;
}

export const PhotoEditorModal: React.FC<PhotoEditorModalProps> = ({
  initialPhotoUrl = '',
  initialScale = 1,
  initialOffsetX = 0,
  initialOffsetY = 0,
  onSave,
  onClose,
}) => {
  const [photoUrl, setPhotoUrl] = useState<string>(initialPhotoUrl);
  const [scale, setScale] = useState<number>(initialScale);
  const [offsetX, setOffsetX] = useState<number>(initialOffsetX);
  const [offsetY, setOffsetY] = useState<number>(initialOffsetY);
  const [isWebcamActive, setIsWebcamActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [facingMode, setFacingMode] = useState<'user' | 'environment'>('user');

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // File upload handler
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setPhotoUrl(event.target?.result as string);
      setScale(1);
      setOffsetX(0);
      setOffsetY(0);
      stopWebcam();
    };
    reader.readAsDataURL(file);
  };

  const stopWebcam = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    if (videoRef.current) {
      videoRef.current.srcObject = null;
    }
    setIsWebcamActive(false);
  }, []);

  // Webcam controls with multi-step fallback to guarantee live feed display
  const startWebcam = async (facing: 'user' | 'environment' = facingMode) => {
    setCameraError(null);
    stopWebcam();

    try {
      let stream: MediaStream | null = null;

      // Attempt 1: Standard high-res constraints
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: {
            facingMode: facing,
            width: { ideal: 1280, min: 320 },
            height: { ideal: 720, min: 240 },
          },
          audio: false,
        });
      } catch (err) {
        console.warn('Attempt 1 failed, trying basic video constraints:', err);
        // Attempt 2: Minimal fallback constraints
        stream = await navigator.mediaDevices.getUserMedia({
          video: true,
          audio: false,
        });
      }

      if (!stream) {
        throw new Error('Unable to acquire media stream');
      }

      streamRef.current = stream;
      setIsWebcamActive(true);

      // Attach to video element
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play().catch((e) => console.warn('Autoplay error:', e));
      }
    } catch (err: any) {
      console.error('Camera access error:', err);
      setIsWebcamActive(false);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setCameraError('Camera access denied. Please click the camera/lock icon in your browser address bar to allow camera access.');
      } else if (err.name === 'NotFoundError' || err.name === 'DevicesNotFoundError') {
        setCameraError('No camera found on this device. Please connect a webcam or upload a photo file.');
      } else {
        setCameraError('Unable to start camera. Please verify device permissions or upload a file.');
      }
    }
  };

  // Switch between front and back camera (for phones/tablets)
  const toggleCameraFacing = () => {
    const nextFacing = facingMode === 'user' ? 'environment' : 'user';
    setFacingMode(nextFacing);
    startWebcam(nextFacing);
  };

  // Synchronize stream with videoRef whenever webcam becomes active or element mounts
  useEffect(() => {
    if (isWebcamActive && videoRef.current && streamRef.current) {
      const video = videoRef.current;
      video.srcObject = streamRef.current;
      video.onloadedmetadata = () => {
        video.play().catch((e) => console.warn('Play on metadata loaded:', e));
      };
    }
  }, [isWebcamActive]);

  // Clean up stream on unmount
  useEffect(() => {
    return () => {
      stopWebcam();
    };
  }, [stopWebcam]);

  const capturePhoto = () => {
    const video = videoRef.current;
    if (!video) return;

    const canvas = document.createElement('canvas');
    const vw = video.videoWidth || 640;
    const vh = video.videoHeight || 640;

    // Crop to 1x1 square centered
    const size = Math.min(vw, vh);
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const startX = (vw - size) / 2;
    const startY = (vh - size) / 2;

    if (facingMode === 'user') {
      // Mirror horizontally for selfie view
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(video, startX, startY, size, size, 0, 0, size, size);
    } else {
      ctx.drawImage(video, startX, startY, size, size, 0, 0, size, size);
    }

    const capturedUrl = canvas.toDataURL('image/jpeg', 0.95);
    setPhotoUrl(capturedUrl);
    setScale(1);
    setOffsetX(0);
    setOffsetY(0);
    stopWebcam();
  };

  const handleApply = () => {
    onSave(photoUrl, scale, offsetX, offsetY);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white max-w-lg w-full shadow-2xl space-y-5">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div>
            <h3 className="font-semibold text-lg text-white">Student 1x1 Photo</h3>
            <p className="text-xs text-slate-400">Capture live with webcam or upload a student portrait</p>
          </div>
          <button
            onClick={() => {
              stopWebcam();
              onClose();
            }}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera Error Alert */}
        {cameraError && (
          <div className="p-3 bg-rose-950/80 border border-rose-500/60 rounded-xl text-xs text-rose-200 flex items-start gap-2.5 animate-fade-in">
            <AlertCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold">{cameraError}</span>
            </div>
            <button
              type="button"
              onClick={() => setCameraError(null)}
              className="text-rose-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Center Preview Viewport */}
        <div className="flex flex-col items-center">
          {isWebcamActive ? (
            /* Live Camera Feed */
            <div className="relative w-64 h-64 rounded-3xl overflow-hidden border-4 border-emerald-500 shadow-xl bg-black flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className={`w-full h-full object-cover ${facingMode === 'user' ? 'scale-x-[-1]' : ''}`}
              />

              {/* Guide Overlay for 1x1 framing */}
              <div className="absolute inset-0 pointer-events-none border border-emerald-400/40 rounded-3xl" />
              <div className="absolute top-2 left-2 text-[10px] bg-black/60 px-2 py-0.5 rounded text-emerald-300 font-mono">
                LIVE CAMERA
              </div>

              {/* Camera Switch button (if user has multiple cameras) */}
              <button
                type="button"
                onClick={toggleCameraFacing}
                className="absolute top-2 right-2 p-1.5 bg-black/60 hover:bg-black/80 text-white rounded-full transition-colors"
                title="Switch Camera (Front/Back)"
              >
                <SwitchCamera className="w-4 h-4" />
              </button>

              {/* Bottom Capture / Cancel buttons */}
              <div className="absolute bottom-3 left-0 right-0 flex justify-center gap-2 px-3">
                <button
                  type="button"
                  onClick={capturePhoto}
                  className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs rounded-full shadow-lg flex items-center gap-1.5 active:scale-95 transition-all"
                >
                  <Camera className="w-4 h-4" />
                  Capture Photo
                </button>
                <button
                  type="button"
                  onClick={stopWebcam}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs rounded-full"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            /* Selected Photo Preview */
            <div className="relative w-56 h-56 rounded-3xl overflow-hidden border-4 border-white shadow-2xl bg-slate-800 flex items-center justify-center">
              {photoUrl ? (
                <div className="w-full h-full overflow-hidden relative">
                  <img
                    src={photoUrl}
                    alt="Preview"
                    className="w-full h-full object-cover select-none pointer-events-none"
                    style={{
                      transform: `scale(${scale}) translate(${offsetX}%, ${offsetY}%)`,
                      transformOrigin: 'center center',
                    }}
                  />
                  {/* Subtle 1x1 guide overlay */}
                  <div className="absolute inset-0 border border-white/20 rounded-3xl pointer-events-none" />
                </div>
              ) : (
                <div className="text-center p-4 text-slate-400">
                  <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
                  <p className="text-xs font-medium">No photo selected</p>
                  <p className="text-[11px] text-slate-500 mt-1">Click &quot;Take Photo&quot; or upload a file below</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Adjustments (Scale & Offset) */}
        {photoUrl && !isWebcamActive && (
          <div className="space-y-3 bg-slate-800/60 p-4 rounded-xl border border-slate-800">
            {/* Zoom Slider */}
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span className="flex items-center gap-1">
                  <ZoomIn className="w-3.5 h-3.5 text-emerald-400" /> Zoom / Scale
                </span>
                <span className="font-mono text-slate-400">{Math.round(scale * 100)}%</span>
              </div>
              <input
                type="range"
                min="0.8"
                max="3.5"
                step="0.05"
                value={scale}
                onChange={(e) => setScale(parseFloat(e.target.value))}
                className="w-full accent-emerald-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
              />
            </div>

            {/* Position Y Slider */}
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span className="flex items-center gap-1">
                  <Move className="w-3.5 h-3.5 text-sky-400" /> Vertical Position
                </span>
                <span className="font-mono text-slate-400">{offsetY}%</span>
              </div>
              <input
                type="range"
                min="-80"
                max="80"
                step="1"
                value={offsetY}
                onChange={(e) => setOffsetY(parseInt(e.target.value, 10))}
                className="w-full accent-sky-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
              />
            </div>

            {/* Position X Slider */}
            <div>
              <div className="flex justify-between text-xs text-slate-300 mb-1">
                <span className="flex items-center gap-1">
                  <Move className="w-3.5 h-3.5 text-sky-400" /> Horizontal Position
                </span>
                <span className="font-mono text-slate-400">{offsetX}%</span>
              </div>
              <input
                type="range"
                min="-80"
                max="80"
                step="1"
                value={offsetX}
                onChange={(e) => setOffsetX(parseInt(e.target.value, 10))}
                className="w-full accent-sky-500 h-1.5 bg-slate-700 rounded-lg cursor-pointer"
              />
            </div>
          </div>
        )}

        {/* Upload / Camera Action Buttons */}
        <div className="grid grid-cols-2 gap-3">
          <label className="flex items-center justify-center gap-2 px-4 py-2.5 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl cursor-pointer text-xs font-semibold text-slate-200 transition-colors">
            <Upload className="w-4 h-4 text-emerald-400" />
            Upload Photo File
            <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
          </label>

          <button
            type="button"
            onClick={() => startWebcam(facingMode)}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/50 rounded-xl text-xs font-semibold text-emerald-300 transition-colors"
          >
            <Camera className="w-4 h-4 text-emerald-400" />
            {isWebcamActive ? 'Restart Camera' : 'Take Photo (Webcam)'}
          </button>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <button
            type="button"
            onClick={() => {
              setScale(1);
              setOffsetX(0);
              setOffsetY(0);
            }}
            className="text-xs text-slate-400 hover:text-white flex items-center gap-1"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Reset Crop
          </button>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                stopWebcam();
                onClose();
              }}
              className="px-3.5 py-2 text-xs font-semibold text-slate-300 hover:text-white rounded-xl bg-slate-800 hover:bg-slate-700 transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handleApply}
              className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-md flex items-center gap-1.5"
            >
              <Check className="w-4 h-4" />
              Apply to ID Card
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
