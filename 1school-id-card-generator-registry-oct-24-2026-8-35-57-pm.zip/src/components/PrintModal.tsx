import React, { useState } from 'react';
import { StudentRecord, PrintSettings } from '../types/student';
import { IdCardFront } from './IdCardFront';
import { IdCardBack } from './IdCardBack';
import { Printer, X, LayoutGrid, Check, Settings2, Scissors } from 'lucide-react';

interface PrintModalProps {
  studentsToPrint: StudentRecord[];
  onClose: () => void;
}

export const PrintModal: React.FC<PrintModalProps> = ({
  studentsToPrint,
  onClose,
}) => {
  const [printSettings, setPrintSettings] = useState<PrintSettings>({
    paperSize: 'A4',
    layout: 'both-side-by-side',
    includeCropMarks: true,
    scalePercent: 100,
    cuttingMarginMm: 3,
  });

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
      {/* Container - hide during print so only the print section renders */}
      <div className="no-print bg-slate-900 border border-slate-800 rounded-2xl p-6 text-white max-w-4xl w-full max-h-[90vh] flex flex-col shadow-2xl space-y-4">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <Printer className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-lg text-white">Print ID Cards</h3>
              <p className="text-xs text-slate-400">
                Ready to print {studentsToPrint.length} student card{studentsToPrint.length > 1 ? 's' : ''} on standard PVC or A4/Letter photo paper
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Print Settings Toolbar */}
        <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700/60 grid grid-cols-1 sm:grid-cols-3 gap-4 text-xs">
          {/* Layout Mode */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Print Format / Layout
            </label>
            <select
              value={printSettings.layout}
              onChange={(e) =>
                setPrintSettings({ ...printSettings, layout: e.target.value as any })
              }
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white font-medium focus:outline-none"
            >
              <option value="both-side-by-side">Front &amp; Back Side-by-Side (Fold &amp; Laminate)</option>
              <option value="single">Front Side Only</option>
              <option value="sheet-4">4 Cards / Sheet Grid</option>
            </select>
          </div>

          {/* Paper Size */}
          <div>
            <label className="block text-slate-300 font-semibold mb-1">
              Paper Size
            </label>
            <select
              value={printSettings.paperSize}
              onChange={(e) =>
                setPrintSettings({ ...printSettings, paperSize: e.target.value as any })
              }
              className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 text-white font-medium focus:outline-none"
            >
              <option value="A4">Standard A4 Paper (210 x 297 mm)</option>
              <option value="Letter">US Letter (8.5 x 11 in)</option>
              <option value="CR80">Direct PVC Card Tray (CR80: 54 x 85.6 mm)</option>
            </select>
          </div>

          {/* Crop Marks Toggle */}
          <div className="flex items-center justify-between sm:justify-start sm:gap-3 pt-4 sm:pt-5">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={printSettings.includeCropMarks}
                onChange={(e) =>
                  setPrintSettings({ ...printSettings, includeCropMarks: e.target.checked })
                }
                className="w-4 h-4 accent-emerald-500 rounded cursor-pointer"
              />
              <span className="font-semibold text-slate-300 flex items-center gap-1">
                <Scissors className="w-3.5 h-3.5 text-slate-400" /> Cutting Guide Marks
              </span>
            </label>
          </div>
        </div>

        {/* Scrollable Print Preview Viewport */}
        <div className="flex-1 overflow-y-auto bg-slate-950 p-6 rounded-xl border border-slate-800 flex justify-center items-center min-h-[360px]">
          <div className="bg-white text-black p-6 rounded shadow-xl flex flex-col items-center">
            <div className="text-[11px] text-slate-400 mb-3 font-mono">
              [Print Preview Mode — Standard Scale: 54mm x 85.6mm]
            </div>

            {/* Render Preview of First Student */}
            {studentsToPrint.length > 0 && (
              <div className="flex flex-wrap items-center justify-center gap-6">
                <div className="relative">
                  <IdCardFront
                    student={studentsToPrint[0]}
                    scale={0.65}
                    forceNoCutMargin={!printSettings.includeCropMarks}
                  />
                </div>

                {printSettings.layout === 'both-side-by-side' && (
                  <div className="relative">
                    <IdCardBack
                      student={studentsToPrint[0]}
                      scale={0.65}
                      forceNoCutMargin={!printSettings.includeCropMarks}
                    />
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="flex items-center justify-between pt-3 border-t border-slate-800">
          <div className="text-xs text-slate-400">
            Tip: In printer settings, set margins to &quot;None&quot; and scale to &quot;100%&quot; for standard PVC fit.
          </div>

          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={handlePrint}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl transition-all shadow-lg flex items-center gap-2"
            >
              <Printer className="w-4 h-4" />
              Print Now
            </button>
          </div>
        </div>
      </div>

      {/* ================= PURE PRINT ONLY VIEWPORT ================= */}
      {/* This element is hidden on screen and rendered exclusively via CSS @media print */}
      <div className="hidden print:block print:w-full print:m-0 print:p-0 print:bg-white text-black">
        {studentsToPrint.map((student, idx) => (
          <div
            key={student.id || idx}
            className="page-break-after p-4 flex flex-wrap items-center justify-center gap-4 min-h-screen"
            style={{ pageBreakAfter: 'always' }}
          >
            {/* Front Card */}
            <div className="relative">
              <IdCardFront
                student={student}
                scale={1}
                forceNoCutMargin={!printSettings.includeCropMarks}
              />
            </div>

            {/* Back Card */}
            {(printSettings.layout === 'both-side-by-side' || printSettings.layout === 'sheet-4') && (
              <div className="relative">
                <IdCardBack
                  student={student}
                  scale={1}
                  forceNoCutMargin={!printSettings.includeCropMarks}
                />
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};
