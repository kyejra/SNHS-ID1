import React, { useState, useEffect } from 'react';
import { PHILIPPINE_ADDRESSES, LOCAL_QUICK_PRESETS, ProvinceData } from '../data/philippineAddresses';
import { MapPin, Check, ChevronDown, Edit3, ListFilter } from 'lucide-react';

interface PhilippineAddressSelectorProps {
  label: string;
  value: string;
  onChange: (formattedAddress: string) => void;
  required?: boolean;
  placeholder?: string;
}

export const PhilippineAddressSelector: React.FC<PhilippineAddressSelectorProps> = ({
  label,
  value,
  onChange,
  required = false,
  placeholder = 'Select or enter address',
}) => {
  const [mode, setMode] = useState<'dropdown' | 'manual'>('dropdown');

  // Cascade selections
  const [selectedProvinceName, setSelectedProvinceName] = useState<string>('Maguindanao del Norte');
  const [selectedCityName, setSelectedCityName] = useState<string>('Sultan Mastura');
  const [selectedBarangay, setSelectedBarangay] = useState<string>('Solon');
  const [purokOrStreet, setPurokOrStreet] = useState<string>('');

  // Selected province object
  const currentProvince: ProvinceData | undefined =
    PHILIPPINE_ADDRESSES.find((p) => p.name === selectedProvinceName) || PHILIPPINE_ADDRESSES[0];

  // Selected city object
  const currentCity =
    currentProvince?.cities.find((c) => c.name === selectedCityName) || currentProvince?.cities[0];

  // Update cascade when province changes
  const handleProvinceChange = (provName: string) => {
    setSelectedProvinceName(provName);
    const prov = PHILIPPINE_ADDRESSES.find((p) => p.name === provName);
    if (prov && prov.cities.length > 0) {
      const firstCity = prov.cities[0];
      setSelectedCityName(firstCity.name);
      if (firstCity.barangays.length > 0) {
        setSelectedBarangay(firstCity.barangays[0]);
      }
    }
  };

  // Update cascade when city changes
  const handleCityChange = (cityName: string) => {
    setSelectedCityName(cityName);
    const city = currentProvince?.cities.find((c) => c.name === cityName);
    if (city && city.barangays.length > 0) {
      setSelectedBarangay(city.barangays[0]);
    }
  };

  // Assemble and commit address from dropdown cascade
  const applyCascadeAddress = (brgy: string, city: string, prov: string, purok?: string) => {
    const extra = (purok ?? purokOrStreet).trim();
    const prefix = extra ? `${extra}, ` : '';
    const formatted = `${prefix}Brgy. ${brgy}, ${city}, ${prov}`;
    onChange(formatted);
  };

  return (
    <div className="space-y-2">
      {/* Label and mode switch */}
      <div className="flex items-center justify-between">
        <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
          <MapPin className="w-3.5 h-3.5 text-emerald-400" />
          {label} {required && <span className="text-emerald-400">*</span>}
        </label>
        <button
          type="button"
          onClick={() => setMode(mode === 'dropdown' ? 'manual' : 'dropdown')}
          className="text-[11px] text-emerald-400 hover:text-emerald-300 font-semibold flex items-center gap-1 transition-colors"
        >
          {mode === 'dropdown' ? (
            <>
              <Edit3 className="w-3 h-3" /> Type Custom
            </>
          ) : (
            <>
              <ListFilter className="w-3 h-3" /> Dropdown Picker
            </>
          )}
        </button>
      </div>

      {/* Mode 1: Dropdown Cascader */}
      {mode === 'dropdown' ? (
        <div className="bg-slate-800/80 border border-slate-700/80 rounded-xl p-3 space-y-2.5">
          {/* Quick Sultan Mastura / Local Catchment Presets */}
          <div>
            <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 mb-1 flex items-center justify-between">
              <span>Quick 1-Click Select (Sultan Mastura &amp; Nearby):</span>
              <span className="text-[9.5px] text-slate-500 font-normal">Click to apply</span>
            </div>
            <div className="flex flex-wrap gap-1 max-h-32 overflow-y-auto pr-1">
              {LOCAL_QUICK_PRESETS.map((preset) => {
                const isSelected = value === preset.value;
                return (
                  <button
                    key={preset.label}
                    type="button"
                    onClick={() => onChange(preset.value)}
                    className={`text-[10.5px] px-2 py-0.5 rounded-md font-medium transition-colors border flex items-center gap-1 ${
                      isSelected
                        ? 'bg-emerald-600 border-emerald-500 text-white font-semibold'
                        : 'bg-slate-800/90 border-slate-700 text-slate-300 hover:bg-slate-700 hover:text-white'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3 text-white" />}
                    {preset.label.replace(', Sultan Mastura', '')}
                  </button>
                );
              })}
            </div>
          </div>

          {/* 3 Cascading Selectors: Province -> City/Municipality -> Barangay */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2 pt-1 border-t border-slate-700/60">
            {/* 1. Province Dropdown */}
            <div>
              <label className="block text-[10px] font-medium text-slate-400 mb-0.5">
                Province
              </label>
              <select
                value={selectedProvinceName}
                onChange={(e) => {
                  handleProvinceChange(e.target.value);
                  const prov = PHILIPPINE_ADDRESSES.find((p) => p.name === e.target.value);
                  const firstCity = prov?.cities[0]?.name || '';
                  const firstBrgy = prov?.cities[0]?.barangays[0] || '';
                  applyCascadeAddress(firstBrgy, firstCity, e.target.value);
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                {PHILIPPINE_ADDRESSES.map((prov) => (
                  <option key={prov.name} value={prov.name}>
                    {prov.name}
                  </option>
                ))}
              </select>
            </div>

            {/* 2. City / Municipality Dropdown */}
            <div>
              <label className="block text-[10px] font-medium text-slate-400 mb-0.5">
                Municipality / City
              </label>
              <select
                value={selectedCityName}
                onChange={(e) => {
                  handleCityChange(e.target.value);
                  const city = currentProvince?.cities.find((c) => c.name === e.target.value);
                  const firstBrgy = city?.barangays[0] || '';
                  applyCascadeAddress(firstBrgy, e.target.value, selectedProvinceName);
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                {currentProvince?.cities.map((city) => (
                  <option key={city.name} value={city.name}>
                    {city.name}
                  </option>
                ))}
              </select>
            </div>

            {/* 3. Barangay Dropdown */}
            <div>
              <label className="block text-[10px] font-medium text-slate-400 mb-0.5">
                Barangay
              </label>
              <select
                value={selectedBarangay}
                onChange={(e) => {
                  setSelectedBarangay(e.target.value);
                  applyCascadeAddress(e.target.value, selectedCityName, selectedProvinceName);
                }}
                className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-white focus:outline-none focus:border-emerald-500"
              >
                {currentCity?.barangays.map((brgy) => (
                  <option key={brgy} value={brgy}>
                    {brgy}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Optional Street / Sitio input */}
          <div className="pt-1">
            <input
              type="text"
              value={purokOrStreet}
              onChange={(e) => {
                setPurokOrStreet(e.target.value);
                applyCascadeAddress(selectedBarangay, selectedCityName, selectedProvinceName, e.target.value);
              }}
              placeholder="Optional: Purok / Sitio / House No. (e.g. Purok 3)"
              className="w-full bg-slate-900/90 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Current Formatted Output Preview */}
          <div className="pt-1.5 border-t border-slate-700/60 flex items-center justify-between text-[11px]">
            <span className="text-slate-400">Selected:</span>
            <span className="font-semibold text-emerald-300 truncate max-w-[320px] text-right font-sans-ui">
              {value || 'None selected'}
            </span>
          </div>
        </div>
      ) : (
        /* Mode 2: Manual Text Input */
        <div>
          <input
            type="text"
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full bg-slate-800/90 border border-slate-700 focus:border-emerald-500 rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
          <p className="text-[11px] text-slate-400 mt-1">
            Manual mode active. You can type freely or click &quot;Dropdown Picker&quot; above.
          </p>
        </div>
      )}
    </div>
  );
};
