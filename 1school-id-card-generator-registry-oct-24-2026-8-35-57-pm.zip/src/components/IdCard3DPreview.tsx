import React, { useState, useRef } from 'react';
import { StudentRecord } from '../types/student';
import { IdCardFront } from './IdCardFront';
import { IdCardBack } from './IdCardBack';
import {
  RotateCw,
  Download,
  Printer,
  Columns,
  Square,
  CheckCircle,
  Sparkles,
  Layers,
} from 'lucide-react';
import { safeToPng } from '../utils/exportImage';
import confetti from 'canvas-confetti';

interface IdCard3DPreviewProps {
  student: StudentRecord;
  onOpenPrintModal: () => void;
}

export const IdCard3DPreview: React.FC<IdCard3DPreviewProps> = ({
  student,
  onOpenPrintModal,
}) => {
  const [viewMode, setViewMode] = useState<'flip' | 'side-by-side' | 'front' | 'back'>('flip');
  const [isFlipped, setIsFlipped] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  // Hidden container references for high-res image extraction
  const frontCaptureRef = useRef<HTMLDivElement | null>(null);
  const backCaptureRef = useRef<HTMLDivElement | null>(null);
  const sideBySideCaptureRef = useRef<HTMLDivElement | null>(null);

  // Download Front PNG
  // Download Front PNG
  const downloadFront = async () => {
    const el = document.getElementById('id-card-front-export') || document.getElementById('id-card-front');
    if (!el) return;
    setIsDownloading(true);
    try {
      const dataUrl = await safeToPng(el, 3);
      const link = document.createElement('a');
      const safeName = (student.fullName || 'student').replace(/[^a-zA-Z0-9]/g, '_');
      link.download = `${safeName}_ID_Front.png`;
      link.href = dataUrl;
      link.click();

      confetti({ particleCount: 30, spread: 40, origin: { y: 0.8 } });
      setDownloadSuccess('Front ID Downloaded!');
      setTimeout(() => setDownloadSuccess(null), 3000);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  // Download Back PNG
  const downloadBack = async () => {
    const el = document.getElementById('id-card-back-export') || document.getElementById('id-card-back');
    if (!el) return;
    setIsDownloading(true);
    try {
      const dataUrl = await safeToPng(el, 3);
      const link = document.createElement('a');
      const safeName = (student.fullName || 'student').replace(/[^a-zA-Z0-9]/g, '_');
      link.download = `${safeName}_ID_Back.png`;
      link.href = dataUrl;
      link.click();

      confetti({ particleCount: 30, spread: 40, origin: { y: 0.8 } });
      setDownloadSuccess('Back ID Downloaded!');
      setTimeout(() => setDownloadSuccess(null), 3000);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  // Download Both (Combined Sheet)
  const downloadBoth = async () => {
    const el = document.getElementById('id-cards-combined-export');
    if (!el) return;
    setIsDownloading(true);
    try {
      const dataUrl = await safeToPng(el, 3);
      const link = document.createElement('a');
      const safeName = (student.fullName || 'student').replace(/[^a-zA-Z0-9]/g, '_');
      link.download = `${safeName}_ID_Full_Set.png`;
      link.href = dataUrl;
      link.click();

      confetti({ particleCount: 50, spread: 60, origin: { y: 0.7 } });
      setDownloadSuccess('Front & Back ID Downloaded!');
      setTimeout(() => setDownloadSuccess(null), 3000);
    } catch (err) {
      console.error('Download combined error:', err);
    } finally {
      setIsDownloading(false);
    }
  };

  const hasCutMargin = student.includeCuttingMargin ?? true;
  const marginExtra = hasCutMargin ? (student.cuttingMarginMm || 3) * 7.56 : 0;
  const flipWidth = `${(450 + marginExtra) * 0.7}px`;
  const flipHeight = `${(714 + marginExtra) * 0.7}px`;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-5 text-white shadow-xl flex flex-col items-center">
      {/* Top Controls Header */}
      <div className="w-full flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div>
          <h3 className="font-bold text-base text-white flex items-center gap-2">
            <Layers className="w-4 h-4 text-emerald-400" />
            Live ID Card Preview
          </h3>
          <p className="text-xs text-slate-400">
            Click flip or switch views · Plain white background with cutting margins
          </p>
        </div>

        {/* View Mode Tabs */}
        <div className="flex items-center gap-1 bg-slate-800/80 p-1 rounded-lg">
          <button
            type="button"
            onClick={() => setViewMode('flip')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 ${
              viewMode === 'flip' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            <RotateCw className="w-3 h-3" />
            3D Flip
          </button>
          <button
            type="button"
            onClick={() => setViewMode('side-by-side')}
            className={`px-2.5 py-1 text-xs font-semibold rounded-md transition-colors flex items-center gap-1 ${
              viewMode === 'side-by-side' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Columns className="w-3 h-3" />
            Side by Side
          </button>
          <button
            type="button"
            onClick={() => setViewMode('front')}
            className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${
              viewMode === 'front' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Front
          </button>
          <button
            type="button"
            onClick={() => setViewMode('back')}
            className={`px-2 py-1 text-xs font-semibold rounded-md transition-colors ${
              viewMode === 'back' ? 'bg-emerald-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
            }`}
          >
            Back
          </button>
        </div>
      </div>

      {/* Center Viewport */}
      <div className="w-full flex justify-center items-center py-2 min-h-[530px] overflow-x-auto">
        {/* Flip 3D View */}
        {viewMode === 'flip' && (
          <div className="flex flex-col items-center space-y-4">
            <div
              className="cursor-pointer group relative"
              style={{
                perspective: '1200px',
                width: flipWidth,
                height: flipHeight,
              }}
              onClick={() => setIsFlipped(!isFlipped)}
              title="Click card to flip between front and back"
            >
              <div
                className="w-full h-full relative transition-transform duration-700 ease-in-out"
                style={{
                  transformStyle: 'preserve-3d',
                  transform: isFlipped ? 'rotateY(180deg)' : 'rotateY(0deg)',
                }}
              >
                {/* Front Card Face */}
                <div
                  className="absolute inset-0 backface-hidden rounded-xl overflow-hidden shadow-2xl border border-slate-700/50"
                  style={{
                    backfaceVisibility: 'hidden',
                    WebkitBackfaceVisibility: 'hidden',
                  }}
                >
                  <IdCardFront student={student} scale={0.7} id="id-card-front" />
                </div>

                {/* Back Card Face */}
                <div
                  className="absolute inset-0 backface-hidden rounded-xl overflow-hidden shadow-2xl border border-slate-700/50"
                  style={{
                    backfaceVisibility: 'hidden',
                    WebkitBackfaceVisibility: 'hidden',
                    transform: 'rotateY(180deg)',
                  }}
                >
                  <IdCardBack student={student} scale={0.7} id="id-card-back" />
                </div>
              </div>
            </div>

            {/* Flip Button */}
            <button
              type="button"
              onClick={() => setIsFlipped(!isFlipped)}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold rounded-xl border border-slate-700 flex items-center gap-2 transition-all shadow-md active:scale-95"
            >
              <RotateCw className="w-3.5 h-3.5 text-emerald-400" />
              Flip to {isFlipped ? 'Front' : 'Back'}
            </button>
          </div>
        )}

        {/* Side by Side View */}
        {viewMode === 'side-by-side' && (
          <div className="flex flex-wrap items-center justify-center gap-6">
            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-emerald-400 uppercase tracking-wider mb-2 font-oswald">
                FRONT SIDE
              </span>
              <div
                className="rounded-xl overflow-hidden shadow-2xl border border-slate-700/50"
                style={{ width: flipWidth, height: flipHeight }}
              >
                <IdCardFront student={student} scale={0.7} id="id-card-front" />
              </div>
            </div>

            <div className="flex flex-col items-center">
              <span className="text-xs font-bold text-yellow-400 uppercase tracking-wider mb-2 font-oswald">
                BACK SIDE
              </span>
              <div
                className="rounded-xl overflow-hidden shadow-2xl border border-slate-700/50"
                style={{ width: flipWidth, height: flipHeight }}
              >
                <IdCardBack student={student} scale={0.7} id="id-card-back" />
              </div>
            </div>
          </div>
        )}

        {/* Front Only */}
        {viewMode === 'front' && (
          <div className="flex flex-col items-center">
            <div
              className="rounded-xl overflow-hidden shadow-2xl border border-slate-700/50"
              style={{
                width: `${(450 + marginExtra) * 0.78}px`,
                height: `${(714 + marginExtra) * 0.78}px`,
              }}
            >
              <IdCardFront student={student} scale={0.78} id="id-card-front" />
            </div>
          </div>
        )}

        {/* Back Only */}
        {viewMode === 'back' && (
          <div className="flex flex-col items-center">
            <div
              className="rounded-xl overflow-hidden shadow-2xl border border-slate-700/50"
              style={{
                width: `${(450 + marginExtra) * 0.78}px`,
                height: `${(714 + marginExtra) * 0.78}px`,
              }}
            >
              <IdCardBack student={student} scale={0.78} id="id-card-back" />
            </div>
          </div>
        )}
      </div>

      {/* Success Notification */}
      {downloadSuccess && (
        <div className="w-full bg-emerald-950/80 border border-emerald-500/50 text-emerald-300 text-xs py-2 px-3 rounded-xl flex items-center justify-center gap-2 animate-fade-in font-medium">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          {downloadSuccess}
        </div>
      )}

      {/* Action Buttons: Download & Print */}
      <div className="w-full pt-4 border-t border-slate-800 space-y-3">
        <div className="text-xs font-semibold text-slate-400 text-center">
          Export &amp; Print Options (300 DPI High-Resolution)
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          <button
            type="button"
            disabled={isDownloading}
            onClick={downloadFront}
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-all shadow-sm active:scale-95 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            Front PNG
          </button>

          <button
            type="button"
            disabled={isDownloading}
            onClick={downloadBack}
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-all shadow-sm active:scale-95 disabled:opacity-50"
          >
            <Download className="w-3.5 h-3.5 text-yellow-400" />
            Back PNG
          </button>

          <button
            type="button"
            disabled={isDownloading}
            onClick={downloadBoth}
            className="flex items-center justify-center gap-1.5 px-3 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 rounded-xl text-xs font-semibold transition-all shadow-sm active:scale-95 disabled:opacity-50"
          >
            <Sparkles className="w-3.5 h-3.5 text-sky-400" />
            Full Set PNG
          </button>

          <button
            type="button"
            onClick={onOpenPrintModal}
            className="flex items-center justify-center gap-1.5 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95"
          >
            <Printer className="w-4 h-4" />
            Print Sheet / PVC
          </button>
        </div>
      </div>

      {/* Hidden Full-Resolution Elements specifically for export */}
      <div className="fixed -top-[9999px] -left-[9999px] pointer-events-none opacity-0">
        <div id="id-card-front-export">
          <IdCardFront student={student} scale={1} id="id-front-full" />
        </div>
        <div id="id-card-back-export">
          <IdCardBack student={student} scale={1} id="id-back-full" />
        </div>
        <div id="id-cards-combined-export" className="flex gap-4 p-4 bg-white">
          <IdCardFront student={student} scale={1} id="id-front-combo" />
          <IdCardBack student={student} scale={1} id="id-back-combo" />
        </div>
      </div>
    </div>
  );
};
