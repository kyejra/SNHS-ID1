import { StudentRecord } from '../types/student';

// Default school header configuration matching Sulon National High School
export const DEFAULT_SCHOOL_CONFIG = {
  republicHeader: 'Republic of the Philippines',
  regionHeader: 'Bangsamoro Autonomous Region in Muslim Mindanao',
  ministryHeader: 'Ministry of Basic, Higher, and Technical Education',
  divisionHeader: 'School Division of Maguindanao del Norte',
  schoolName: 'SULON NATIONAL HIGH SCHOOL',
  schoolAddress: 'Solon, Sultan Mastura, Maguindanao del Norte',
  schoolIdNumber: '326501',
  principalName: 'LUNA L. SLA',
  principalTitle: 'Principal I',
  principalSignatureUrl: '',
  showPrincipalSignature: false, // Removed per request

  // Official Sulon National High School Seal by default from uploaded image
  schoolLogoUrl: '/assets/aistudio/NO_PHOTO_51d01644.png',
  backgroundUrl: '', // Plain White default
  backgroundOpacity: 0.2,
  backgroundBlur: 0,
  showFrontLogoWatermark: false, // Clean plain white without logo interference

  // Cutting allowance margin on all sides
  includeCuttingMargin: true,
  cuttingMarginMm: 3,

  // Editable Color Schemes for Junior & Senior High
  juniorHighColor: '#22c55e',
  juniorHighStrokeColor: '#000000',
  seniorHighColor: '#facc15',
  seniorHighStrokeColor: '#000000',
  headerBgStart: '#15803d',
  headerBgEnd: '#4ade80',
  schoolNameColor: '#fde047',
};

export const SAMPLE_STUDENTS: StudentRecord[] = [
  {
    id: 'student-tonggal-01',
    ...DEFAULT_SCHOOL_CONFIG,
    lrn: '134171190015',
    fullName: 'TONGGAL E. ASGAR',
    level: 'JUNIOR HIGH SCHOOL',
    birthDate: '2014-07-18',
    studentAddress: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
    emergencyContactName: 'Bimbing E. Asgar',
    emergencyContactAddress: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
    emergencyContactPhone: '0935-028-3612',
    photoUrl: '/assets/aistudio/Done__1__32b471d1.jpg',
    photoScale: 2.3,
    photoOffsetX: -14,
    photoOffsetY: -48,
    signatureUrl: '',
    createdAt: '2026-10-20T08:00:00Z',
    updatedAt: '2026-10-23T10:00:00Z',
  },
  {
    id: 'student-sahjid-02',
    ...DEFAULT_SCHOOL_CONFIG,
    lrn: '134234150046',
    fullName: 'SAHJID T. KASAN',
    level: 'SENIOR HIGH SCHOOL',
    trackStrand: 'HUMSS',
    birthDate: '2010-09-29',
    studentAddress: 'Brgy. Dagurongan, Sultan Mastura, Maguindanao del Norte',
    emergencyContactName: 'Eden Tariwasay',
    emergencyContactAddress: 'Brgy. Dagurongan, Sultan Mastura, Maguindanao del Norte',
    emergencyContactPhone: '0997-497-2215',
    photoUrl: '/assets/aistudio/1_815d7f0c.jpg',
    photoScale: 2.3,
    photoOffsetX: -14,
    photoOffsetY: -48,
    signatureUrl: '',
    createdAt: '2026-10-21T09:15:00Z',
    updatedAt: '2026-10-23T11:30:00Z',
  },
  {
    id: 'student-fatima-03',
    ...DEFAULT_SCHOOL_CONFIG,
    lrn: '134171200088',
    fullName: 'FATIMA MAE MACACUA-DATULUMANONG',
    level: 'JUNIOR HIGH SCHOOL',
    birthDate: '2013-11-12',
    studentAddress: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
    emergencyContactName: 'Khadija M. Macacua',
    emergencyContactAddress: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
    emergencyContactPhone: '0917-889-4321',
    photoUrl: '',
    photoScale: 1,
    photoOffsetX: 0,
    photoOffsetY: 0,
    signatureUrl: '',
    createdAt: '2026-10-22T08:30:00Z',
    updatedAt: '2026-10-23T09:00:00Z',
  },
];

export const formatBirthDateDisplay = (dateString: string): string => {
  if (!dateString) return 'Not Specified';
  try {
    const parts = dateString.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      const date = new Date(year, month, day);
      return date.toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });
    }
    const d = new Date(dateString);
    if (isNaN(d.getTime())) return dateString;
    return d.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return dateString;
  }
};
