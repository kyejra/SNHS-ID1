/**
 * Official Philippine Standard Geographic Code (PSGC) Divisions
 * Strictly following the official classification for Maguindanao del Norte, Maguindanao del Sur, and Cotabato City.
 * Reference: https://psa.gov.ph/classification/psgc & Barangays_and_Province_of_MDN guide.
 */

export interface ProvinceData {
  name: string;
  region: string;
  cities: {
    name: string;
    barangays: string[];
  }[];
}

export const PHILIPPINE_ADDRESSES: ProvinceData[] = [
  // 1. MAGUINDANAO DEL NORTE (Primary School Catchment Division)
  {
    name: 'Maguindanao del Norte',
    region: 'BARMM',
    cities: [
      {
        name: 'Sultan Mastura',
        barangays: [
          'Solon', // Sulon NHS Campus location
          'Tambo',
          'Macabiso',
          'Bungabong',
          'Boliok',
          'Kirkir',
          'Namuken',
          'Simuay Seashore',
          'Tapayan',
          'Tariken',
          'Tuka',
          'Balut',
          'Dagurongan',
        ],
      },
      {
        name: 'Sultan Kudarat (Nuling)',
        barangays: [
          'Crossing Simuay',
          'Dalumangcob (Poblacion)',
          'Banatin',
          'Salimbao',
          'Bulalo',
          'Katidtuan',
          'Alamada',
          'Banubo',
          'Bulibod',
          'Calsada',
          'Damaniog',
          'Darapanan',
          'Gang',
          'Inawan',
          'Kakar',
          'Katuli',
          'Ladia',
          'Limbo',
          'Maidapa',
          'Makaguiling',
          'Matengen',
          'Mulaug',
          'Nara',
          'Nekitan',
          'Olas',
          'Panatan',
          'Pigcalagan',
          'Pigkelegan',
          'Pinaring',
          'Pingping',
          'Raguisi',
          'Rebuken',
          'Sambolawan',
          'Senditan',
          'Ungap',
        ],
      },
      {
        name: 'Parang',
        barangays: [
          'Poblacion',
          'Making',
          'Polloc',
          'Landasan (Sarmiento)',
          'Nituan',
          'Bongo Island (Litayen)',
          'Campo Islam',
          'Cotongan',
          'Datu Macarimbang Biruar',
          'Gadungan',
          'Gadungan Pedpandaran',
          'Guiday T. Biruar',
          'Gumagadong Calawag',
          'Kabuan',
          'Limbayan',
          'Magsaysay',
          'Orandang',
          'Pinantao',
          'Tagudtongan',
          'Tuca-Maror',
        ],
      },
      {
        name: 'Datu Odin Sinsuat (Dinaig)',
        barangays: [
          'Dalican Poblacion',
          'Awang',
          'Ambolodto',
          'Badak',
          'Bagoenged',
          'Baka',
          'Benolen',
          'Bitu',
          'Bongued',
          'Bugawas',
          'Capiton',
          'Dados',
          'Dinaig Proper',
          'Dulangan',
          'Kakar',
          'Kenebeka',
          'Kurintem',
          'Kusiong',
          'Labungan',
          'Linek',
          'Makir',
          'Margues',
          'Mompong',
          'Nekitan',
          'Sapalan',
          'Semba',
          'Sibuto',
          'Sifaran',
          'Tambak',
          'Tamontaka',
          'Tanuel',
          'Tapian',
          'Taviran',
          'Tenonggos',
        ],
      },
      {
        name: 'Barira',
        barangays: [
          'Barira (Poblacion)',
          'Bualan',
          'Gadung (Mopak)',
          'Korosoyan',
          'Lamin',
          'Liong',
          'Lipa',
          'Lipawan',
          'Marang',
          'Minabay',
          'Nabalawag',
          'Panggao',
          'Rominimbang',
          'Togaig',
        ],
      },
      {
        name: 'Buldon',
        barangays: [
          'Calaan (Poblacion)',
          'Ampuan',
          'Aratuc',
          'Cabayuan',
          'Dinganen',
          'Edcor (Gallego Edcor)',
          'Karim',
          'Kulimpang',
          'Mataya',
          'Minabay',
          'Nuyo',
          'Pantawan',
          'Piers',
          'Puracan',
          'Rumidas',
        ],
      },
      {
        name: 'Datu Blah T. Sinsuat',
        barangays: [
          'Poblacion',
          'Kinimi',
          'Laguitan',
          'Lapaken',
          'Matuber',
          'Meti',
          'Nuro Blah',
          'Penansaran',
          'Pura',
          'Resa',
          'Sedem',
          'Sinipak',
          'Tambak',
          'Tubuan',
        ],
      },
      {
        name: 'Kabuntalan (Tumbao)',
        barangays: [
          'Poblacion',
          'Bagumbayan',
          'Butilen',
          'Dadtumeg',
          'Gambar',
          'Gambing',
          'Guiawa',
          'Indatuan',
          'Katidtuan',
          'Langeban',
          'Liong',
          'Maitum',
          'Matagabong',
          'Payan',
          'Pedtad',
          'Pened',
          'Saagan',
        ],
      },
      {
        name: 'Matanog',
        barangays: [
          'Bugasan Sur (Poblacion)',
          'Bayanga Norte',
          'Bayanga Sur',
          'Bugasan Norte',
          'Kidama',
          'Langco',
          'Langkong',
          'Sapad',
        ],
      },
      {
        name: 'Northern Kabuntalan',
        barangays: [
          'Balong',
          'Damatulan',
          'Gayonga',
          'Guiawa',
          'Indatuan',
          'Kapimpilan',
          'Libungan',
          'Montawal',
          'Paulino Labio',
          'Sabaken',
          'Tumaguinting',
        ],
      },
      {
        name: 'Talitay (Sultan Sumagka)',
        barangays: [
          'Poblacion',
          'Adaon',
          'Bintan (Bentan)',
          'Gadungan',
          'Kiladap',
          'Kilalan',
          'Kuden',
          'Makadayon',
          'Manggay',
          'Mapayag',
        ],
      },
      {
        name: 'Upi',
        barangays: [
          'Nuro (Poblacion)',
          'Bantek',
          'Bayabas',
          'Blensong',
          'Borongotan',
          'Bugabungan',
          'Bungcog',
          'Darugao',
          'Ganasi',
          'Kibleg',
          'Kibucay',
          'Kiga',
          'Kinitan',
          'Mirab',
          'Ranao Babayan',
          'Remipes',
          'Renede',
          'Renede Subah',
          'Rifao',
          'Sefegefen',
          'Tinungkaan',
        ],
      },
    ],
  },

  // 2. COTABATO CITY (Chartered / Special Geographic Area)
  {
    name: 'Cotabato City',
    region: 'BARMM',
    cities: [
      {
        name: 'Cotabato City',
        barangays: [
          'Bagua 1',
          'Bagua 2',
          'Bagua 3',
          'Bagua Mother',
          'Kalanganan 1',
          'Kalanganan 2',
          'Kalanganan Mother',
          'Poblacion 1',
          'Poblacion 2',
          'Poblacion 3',
          'Poblacion 4',
          'Poblacion 5',
          'Poblacion 6',
          'Poblacion 7',
          'Poblacion 8',
          'Poblacion 9',
          'Poblacion Mother',
          'Rosary Heights 1',
          'Rosary Heights 2',
          'Rosary Heights 3',
          'Rosary Heights 4',
          'Rosary Heights 5',
          'Rosary Heights 6',
          'Rosary Heights 7',
          'Rosary Heights 8',
          'Rosary Heights 9',
          'Rosary Heights 10',
          'Rosary Heights 11',
          'Rosary Heights 12',
          'Rosary Heights 13',
          'Rosary Heights Mother',
          'Tamontaka 1',
          'Tamontaka 2',
          'Tamontaka 3',
          'Tamontaka 4',
          'Tamontaka 5',
          'Tamontaka Mother',
        ],
      },
    ],
  },

  // 3. MAGUINDANAO DEL SUR
  {
    name: 'Maguindanao del Sur',
    region: 'BARMM',
    cities: [
      {
        name: 'Ampatuan',
        barangays: ['Poblacion', 'Datu Hoffer', 'Kakal', 'Kamasi', 'Kapinpilan', 'Malatimon', 'Matagabong', 'Salman', 'Saniag', 'Tomicor', 'Tubak'],
      },
      {
        name: 'Buluan',
        barangays: ['Poblacion', 'Digal', 'Lower Siling', 'Masituret', 'Popol', 'Talitay', 'Upper Siling'],
      },
      {
        name: 'Datu Abdullah Sangki',
        barangays: ['Poblacion', 'Banaba', 'Dimampao', 'Guinibon', 'Kaya-kaya', 'Magaslong', 'Mao', 'Maranding', 'Sugadol', 'Talisawa', 'Tukanolocag'],
      },
      {
        name: 'Datu Anggal Midtimbang',
        barangays: ['Midtimbang (Poblacion)', 'Adaon', 'Brar', 'Mapayag', 'Nunangan', 'Tugal', 'Tulunan'],
      },
      {
        name: 'Datu Hoffer Ampatuan',
        barangays: ['Poblacion', 'Kubentog', 'Labu-labu', 'Limpongo', 'Macalag', 'Sayap', 'Tauma', 'Tuayan'],
      },
      {
        name: 'Datu Montawal (Pagagawan)',
        barangays: ['Pagagawan (Poblacion)', 'Bulit', 'Bulod', 'Dungguan', 'Limbalud', 'Maridagao', 'Nabundas', 'Talapas', 'Talitay', 'Tunggol'],
      },
      {
        name: 'Datu Paglas',
        barangays: ['Poblacion', 'Alip', 'Damawato', 'Datupalas', 'Elbebe', 'Kalumenga', 'Katil', 'Lipao', 'Madidis', 'Malala', 'Mangadeg', 'Marantaon', 'Palao sa Buto', 'Puypuy', 'Sepaka'],
      },
      {
        name: 'Datu Piang (Dulawan)',
        barangays: ['Poblacion', 'Ambadao', 'Balanakan', 'Balong', 'Buayan', 'Dado', 'Damabalas', 'Duaminanga', 'Kalipapa', 'Liong', 'Magaslong', 'Masigay', 'Montay', 'Reina Regente'],
      },
      {
        name: 'Datu Salibo',
        barangays: ['Poblacion', 'Alonganan', 'Balanakan', 'Buayan', 'Pandi', 'Penditen', 'Sambulawan', 'Tee'],
      },
      {
        name: 'Datu Saudi Ampatuan',
        barangays: ['Dapiawan (Poblacion)', 'Bakat', 'Elian', 'Ganta', 'Kabatangan', 'Kitango', 'Kitapok', 'Madia', 'Salbu'],
      },
      {
        name: 'Datu Unsay',
        barangays: ['Poblacion', 'Iganagampong', 'Macalan', 'Maitumaig', 'Meta', 'Panat', 'Tuntungan'],
      },
      {
        name: 'General Salipada K. Pendatun',
        barangays: ['Poblacion', 'Badak', 'Baiman', 'Damakling', 'Kulasi', 'Lao-lao', 'Lasangan', 'Lower Idtig', 'Makainis', 'Midpandacan', 'Panadtaban', 'Pidtiguian', 'Poging', 'Ramcor', 'Tonggol', 'Upper Idtig'],
      },
      {
        name: 'Guindulungan',
        barangays: ['Poblacion', 'Ahan', 'Bagan', 'Dalandang', 'Gadungan', 'Kalakat', 'Kateman', 'Lambayong', 'Macasampen', 'Muslim', 'Muti', 'Sampao'],
      },
      {
        name: 'Mamasapano',
        barangays: ['Poblacion', 'Bagumbayan', 'Dalimbang', 'Dasikil', 'Duka', 'Libutan', 'Lusay', 'Mamasapano', 'Manunggal', 'Pagatin', 'Pimbalakan', 'Pidsandawan', 'Tuka', 'Tukanalipao'],
      },
      {
        name: 'Mangudadatu',
        barangays: ['Poblacion', 'Daladagan', 'Kalyan', 'Luayan', 'Paitan', 'Panapan', 'Patadon', 'Tinambulan', 'Tumbao'],
      },
      {
        name: 'Pagalungan',
        barangays: ['Poblacion', 'Bagoinged', 'Buliok', 'Damalasak', 'Galakit', 'Inug-ug', 'Kalbugan', 'Kilangan', 'Kudal', 'Layog', 'Linandangan'],
      },
      {
        name: 'Paglat',
        barangays: ['Poblacion', 'Campo', 'Damakling', 'Damawato', 'Kakal', 'Kalumenga', 'Salam', 'Tual', 'Upper Idtig'],
      },
      {
        name: 'Pandag',
        barangays: ['Poblacion', 'Kabuling', 'Kayaga', 'Kayupo', 'Lepak', 'Lower Dilag', 'Malangit', 'Pandag', 'Upper Dilag'],
      },
      {
        name: 'Rajah Buayan',
        barangays: ['Sapakan (Poblacion)', 'Baital', 'Bakat', 'Dapantis', 'Gaunan', 'Malalan', 'Mileb', 'Panadtaban', 'Pidsandawan', 'Sampao', 'Tabungao', 'Tumiao'],
      },
      {
        name: 'Shariff Aguak (Maganoy)',
        barangays: ['Poblacion', 'Bagong', 'Bialong', 'Kuloy', 'Labu-labu', 'Lapok', 'Matingayan', 'Satan', 'Tapikan', 'Timbangan'],
      },
      {
        name: 'Shariff Saydona Mustapha',
        barangays: ['Poblacion', 'Bakat', 'Datu Bakal', 'Datu Gani', 'Datu Pendililang', 'Datu Romimbang', 'Dale-Bong', 'Libutan', 'Linantangan', 'Nabundas', 'Pagatin', 'Pamalian', 'Pikeg', 'Pusao'],
      },
      {
        name: 'South Upi',
        barangays: ['Romongaob (Poblacion)', 'Babatu', 'Biarong', 'Bito', 'Kuya', 'Lamud', 'Looy', 'Pandan', 'Pilar', 'San Jose', 'Timanan'],
      },
      {
        name: 'Sultan sa Barongis (Lambayong)',
        barangays: ['Poblacion', 'Angkayamat', 'Barurao', 'Bulod', 'Darampua', 'Gadungan', 'Kulambog', 'Langgapan', 'Masulot', 'Papakan', 'Paldong', 'Sampao', 'Tugal'],
      },
      {
        name: 'Talayan',
        barangays: ['Poblacion', 'Boboguiron', 'Damablac', 'Fugotan', 'Fukol', 'Katibpuan', 'Kedatun', 'Linamanan', 'Marader', 'Muslim', 'Tamar', 'Tambunan', 'Timba', 'Tubuan'],
      },
    ],
  },

  // 4. COTABATO (NORTH COTABATO) - Region XII
  {
    name: 'Cotabato (North Cotabato)',
    region: 'Region XII',
    cities: [
      {
        name: 'Midsayap',
        barangays: ['Poblacion 1', 'Poblacion 2', 'Poblacion 3', 'Poblacion 4', 'Poblacion 5', 'Poblacion 6', 'Poblacion 7', 'Poblacion 8', 'Agriculture', 'Anonang', 'Bual Norte', 'Bual Sur', 'Central Katingawan', 'Kapinpilan', 'Katingawan', 'Kimagango', 'Olandang', 'Patindeguen', 'Sambulawan', 'Villarica'],
      },
      {
        name: 'Pigcawayan',
        barangays: ['Poblacion 1', 'Poblacion 2', 'Poblacion 3', 'Anick', 'Balogo', 'Buricatan', 'Capayuran', 'Datu Mantil', 'Kadingilan', 'Libungan Torreta', 'New Culasi', 'Sultan Sabar'],
      },
      {
        name: 'Libungan',
        barangays: ['Poblacion', 'Barongis', 'Batiocan', 'Demapaco', 'Grebona', 'Gumaga', 'Kapinpilan', 'Kilavarn', 'Montay', 'Nica-an', 'Sinawingan'],
      },
      {
        name: 'Kidapawan City',
        barangays: ['Poblacion', 'Balindog', 'Ginatilan', 'Ilomavis', 'Lanao', 'Manongol', 'Paco', 'Sudapin'],
      },
      {
        name: 'Pikit',
        barangays: ['Poblacion', 'Bagoinged', 'Balatican', 'Batulawan', 'Buliok', 'Dapulog', 'Fort Pikit', 'Ginatilan', 'Inug-ug', 'Kolambog', 'Macabual', 'Rajah Muda', 'Silik', 'Takepan'],
      },
      {
        name: 'Aleosan',
        barangays: ['Poblacion', 'Bagolibas', 'Cawilihan', 'Dualing', 'Katalicanan', 'New Panay', 'Pagangan', 'San Mateo', 'Santa Cruz', 'Tapodoc'],
      },
      {
        name: 'Kabacan',
        barangays: ['Poblacion', 'Aringay', 'Bannawag', 'Cuyapon', 'Katidtuan', 'Kayaga', 'Kilagasan', 'Malamote', 'Osias', 'Pedtad', 'Simone'],
      },
    ],
  },

  // 5. SOUTH COTABATO - Region XII
  {
    name: 'South Cotabato',
    region: 'Region XII',
    cities: [
      {
        name: 'General Santos City (Dadiangas)',
        barangays: ['Bula', 'Calumpang', 'City Heights', 'Dadiangas East', 'Dadiangas North', 'Dadiangas South', 'Dadiangas West', 'Fatima', 'Lagao', 'Labangal', 'San Isidro', 'Tambler'],
      },
      {
        name: 'Koronadal City (Marbel)',
        barangays: ['General Paulino Santos', 'Morales', 'Zone I', 'Zone II', 'Zone III', 'Zone IV', 'Carpenter Hill', 'Concepcion', 'Esperanza', 'Rotonda', 'San Roque'],
      },
      {
        name: 'Polomolok',
        barangays: ['Poblacion', 'Cannery Site', 'Glamang', 'Kinilis', 'Klinan 6', 'Malisbog', 'Pagalungan', 'Rubber', 'Silway 8', 'Sulit'],
      },
    ],
  },
];

/**
 * 13 Official Sultan Mastura Catchment Barangays & Key Immediate Neighbors
 * Accurate to the official PSA PSGC 1908711000 directory
 */
export const LOCAL_QUICK_PRESETS = [
  {
    label: 'Brgy. Solon (Sulon NHS Campus)',
    value: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Tambo',
    value: 'Brgy. Tambo, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Macabiso',
    value: 'Brgy. Macabiso, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Bungabong',
    value: 'Brgy. Bungabong, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Boliok',
    value: 'Brgy. Boliok, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Kirkir',
    value: 'Brgy. Kirkir, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Namuken',
    value: 'Brgy. Namuken, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Simuay Seashore',
    value: 'Brgy. Simuay Seashore, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Tapayan',
    value: 'Brgy. Tapayan, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Tariken',
    value: 'Brgy. Tariken, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Tuka',
    value: 'Brgy. Tuka, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Balut',
    value: 'Brgy. Balut, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Dagurongan',
    value: 'Brgy. Dagurongan, Sultan Mastura, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Crossing Simuay, Sultan Kudarat',
    value: 'Brgy. Crossing Simuay, Sultan Kudarat, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Dalumangcob, Sultan Kudarat',
    value: 'Brgy. Dalumangcob (Poblacion), Sultan Kudarat, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Banatin, Sultan Kudarat',
    value: 'Brgy. Banatin, Sultan Kudarat, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Salimbao, Sultan Kudarat',
    value: 'Brgy. Salimbao, Sultan Kudarat, Maguindanao del Norte',
  },
  {
    label: 'Brgy. Making, Parang',
    value: 'Brgy. Making, Parang, Maguindanao del Norte',
  },
  {
    label: 'Rosary Heights, Cotabato City',
    value: 'Rosary Heights, Cotabato City',
  },
];
