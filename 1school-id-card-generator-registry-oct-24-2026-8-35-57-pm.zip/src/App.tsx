/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { StudentRecord } from './types/student';
import { SAMPLE_STUDENTS, DEFAULT_SCHOOL_CONFIG } from './data/sampleStudents';
import { StudentForm } from './components/StudentForm';
import { IdCard3DPreview } from './components/IdCard3DPreview';
import { SpreadsheetManager } from './components/SpreadsheetManager';
import { PrintModal } from './components/PrintModal';
import { SchoolSeal } from './components/SchoolSeal';
import {
  CreditCard,
  FileSpreadsheet,
  Printer,
  Sparkles,
  Download,
  Info,
  CheckCircle2,
  Lock,
  Unlock,
  ShieldCheck,
  ShieldAlert,
  Plus,
} from 'lucide-react';

const STORAGE_KEY = 'sulon_nhs_student_registry_v1';

export default function App() {
  // Students state with localStorage hydration
  const [students, setStudents] = useState<StudentRecord[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed.map((s) => ({
            ...DEFAULT_SCHOOL_CONFIG,
            ...s,
            backgroundUrl: s.backgroundUrl === '/assets/aistudio/Done__1__32b471d1.jpg' ? '' : (s.backgroundUrl || ''),
            showFrontLogoWatermark: s.showFrontLogoWatermark ?? false,
            includeCuttingMargin: s.includeCuttingMargin ?? true,
            cuttingMarginMm: s.cuttingMarginMm || 3,
            showPrincipalSignature: s.showPrincipalSignature ?? false,
            juniorHighColor: s.juniorHighColor || '#22c55e',
            juniorHighStrokeColor: s.juniorHighStrokeColor || '#000000',
            seniorHighColor: s.seniorHighColor || '#facc15',
            seniorHighStrokeColor: s.seniorHighStrokeColor || '#000000',
          }));
        }
      }
    } catch (e) {
      console.error('Failed to load students from localStorage:', e);
    }
    return SAMPLE_STUDENTS;
  });

  // Admin access state - strictly separate student view from admin tools (Registry, Spreadsheet, ID Customization)
  const [isAdminUnlocked, setIsAdminUnlocked] = useState<boolean>(false);
  const [showAdminLoginModal, setShowAdminLoginModal] = useState<boolean>(false);
  const [adminPinInput, setAdminPinInput] = useState<string>('');
  const [pinError, setPinError] = useState<string | null>(null);

  // Currently active student for editing & preview
  const [activeStudentId, setActiveStudentId] = useState<string>(() => {
    return students[0]?.id || SAMPLE_STUDENTS[0].id;
  });

  // Current active view
  const [activeNav, setActiveNav] = useState<'designer' | 'registry' | 'guidelines'>('designer');

  // Print modal trigger
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);
  const [studentsToPrint, setStudentsToPrint] = useState<StudentRecord[]>([]);

  // Notification banner
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
    } catch (e) {
      console.error('Failed to save to localStorage:', e);
    }
  }, [students]);

  // Current student record
  const currentStudent =
    students.find((s) => s.id === activeStudentId) || students[0] || SAMPLE_STUDENTS[0];

  // Update current student
  const handleStudentChange = (updated: StudentRecord) => {
    setStudents((prev) =>
      prev.map((s) => (s.id === updated.id ? updated : s))
    );
  };

  // Save to registry explicit action
  const handleSaveToRegistry = () => {
    setToastMessage('Student details saved successfully to the registry!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Create new student
  const handleNewStudent = () => {
    const newStudent: StudentRecord = {
      ...DEFAULT_SCHOOL_CONFIG,
      id: `student-${Date.now()}`,
      lrn: '',
      fullName: '',
      level: 'JUNIOR HIGH SCHOOL',
      birthDate: '2014-01-01',
      studentAddress: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
      emergencyContactName: '',
      emergencyContactAddress: 'Brgy. Solon, Sultan Mastura, Maguindanao del Norte',
      emergencyContactPhone: '',
      photoUrl: '',
      signatureUrl: '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    setStudents((prev) => [newStudent, ...prev]);
    setActiveStudentId(newStudent.id);
    setActiveNav('designer');
    setToastMessage('New blank student form created!');
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Print single student
  const handlePrintCurrent = () => {
    setStudentsToPrint([currentStudent]);
    setIsPrintModalOpen(true);
  };

  // Print batch
  const handleBatchPrint = (batch: StudentRecord[]) => {
    setStudentsToPrint(batch.length > 0 ? batch : [currentStudent]);
    setIsPrintModalOpen(true);
  };

  const handleAdminLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (adminPinInput.trim() === '102897') {
      setIsAdminUnlocked(true);
      setShowAdminLoginModal(false);
      setPinError(null);
      setAdminPinInput('');
      setToastMessage('Admin mode unlocked! Spreadsheet Registry & Template Customization now active.');
      setTimeout(() => setToastMessage(null), 3000);
    } else {
      setPinError('Incorrect PIN code. Access denied.');
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans-ui selection:bg-emerald-500 selection:text-white">
      {/* ================= TOP BAR ================= */}
      <header className="no-print sticky top-0 z-40 bg-slate-900/95 backdrop-blur-md border-b border-slate-800/80 px-6 py-3.5">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-8">
          {/* Zone 1: Single text element wordmark with uploaded official logo */}
          <div className="flex items-center gap-3 whitespace-nowrap shrink-0">
            <img
              src="/assets/aistudio/NO_PHOTO_51d01644.png"
              alt="Sulon National High School Official Seal"
              className="w-9 h-9 object-contain rounded-full shadow-md shrink-0 bg-white p-0.5 border border-amber-400/40"
            />
            <span className="text-base font-bold tracking-tight text-white font-oswald uppercase">
              Sulon National High School · ID Generator
            </span>
          </div>

          {/* Zone 2: Navigation Links (Registry is ADMIN ONLY as requested) */}
          <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
            <button
              type="button"
              onClick={() => setActiveNav('designer')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeNav === 'designer' ? 'text-emerald-400 font-bold border-b-2 border-emerald-400 pb-0.5' : ''
              }`}
            >
              Card Designer
            </button>

            {/* Student Registry: ADMIN ONLY */}
            {isAdminUnlocked ? (
              <>
                <button
                  type="button"
                  onClick={() => setActiveNav('registry')}
                  className={`hover:text-white transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
                    activeNav === 'registry' ? 'text-amber-400 font-bold border-b-2 border-amber-400 pb-0.5' : 'text-amber-200'
                  }`}
                >
                  <FileSpreadsheet className="w-3.5 h-3.5 text-amber-400" />
                  Student Registry ({students.length})
                </button>
                <button
                  type="button"
                  onClick={() => setActiveNav('registry')}
                  className="hover:text-white transition-colors whitespace-nowrap shrink-0 text-amber-200/90"
                >
                  Spreadsheet Export
                </button>
              </>
            ) : null}

            <button
              type="button"
              onClick={() => setActiveNav('guidelines')}
              className={`hover:text-white transition-colors whitespace-nowrap shrink-0 ${
                activeNav === 'guidelines' ? 'text-emerald-400 font-bold border-b-2 border-emerald-400 pb-0.5' : ''
              }`}
            >
              ID Specifications
            </button>
          </nav>

          {/* Zone 3: Admin Status & Print Action */}
          <div className="flex items-center gap-3 shrink-0">
            {isAdminUnlocked ? (
              <button
                type="button"
                onClick={() => {
                  setIsAdminUnlocked(false);
                  if (activeNav === 'registry') setActiveNav('designer');
                  setToastMessage('Locked in Student Mode. Student Registry is hidden.');
                  setTimeout(() => setToastMessage(null), 3000);
                }}
                className="px-3 py-1.5 text-xs font-bold text-amber-200 bg-amber-950/80 border border-amber-500/50 hover:bg-amber-900 rounded-xl transition-all flex items-center gap-1.5"
                title="Lock admin controls for student access"
              >
                <Unlock className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden sm:inline">Admin Mode (Lock)</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={() => setShowAdminLoginModal(true)}
                className="px-3 py-1.5 text-xs font-semibold text-slate-300 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl transition-all flex items-center gap-1.5"
                title="Unlock Admin Registry & School Settings"
              >
                <Lock className="w-3.5 h-3.5 text-slate-400" />
                <span className="hidden sm:inline">Admin Access</span>
              </button>
            )}

            <button
              type="button"
              onClick={handlePrintCurrent}
              className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-500 rounded-xl transition-all shadow-md flex items-center gap-2 whitespace-nowrap shrink-0 active:scale-95"
            >
              <Printer className="w-4 h-4" />
              Print ID
            </button>
          </div>
        </div>
      </header>

      {/* Toast Banner */}
      {toastMessage && (
        <div className="no-print fixed top-16 right-6 z-50 bg-emerald-950/90 border border-emerald-500/80 text-emerald-200 px-4 py-2.5 rounded-xl text-xs font-semibold shadow-2xl flex items-center gap-2 animate-fade-in backdrop-blur-md">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          {toastMessage}
        </div>
      )}

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 space-y-6">
        {/* Mobile Navigation Pills */}
        <div className="md:hidden flex items-center gap-2 overflow-x-auto pb-1">
          <button
            type="button"
            onClick={() => setActiveNav('designer')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg shrink-0 ${
              activeNav === 'designer' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            Designer &amp; Preview
          </button>
          {isAdminUnlocked && (
            <button
              type="button"
              onClick={() => setActiveNav('registry')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg shrink-0 ${
                activeNav === 'registry' ? 'bg-amber-600 text-white' : 'bg-slate-800 text-amber-200'
              }`}
            >
              Spreadsheet Registry ({students.length})
            </button>
          )}
          <button
            type="button"
            onClick={() => setActiveNav('guidelines')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-lg shrink-0 ${
              activeNav === 'guidelines' ? 'bg-emerald-600 text-white' : 'bg-slate-800 text-slate-300'
            }`}
          >
            Specifications
          </button>
        </div>

        {/* VIEW 1: DESIGNER & LIVE CARD PREVIEW */}
        {activeNav === 'designer' && (
          <div className="space-y-6">
            {/* Quick Context Strip */}
            <div className="bg-slate-900/60 border border-slate-800/80 rounded-2xl px-5 py-3 flex flex-wrap items-center justify-between gap-3 text-xs text-slate-300">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white uppercase font-oswald tracking-wide">
                  Editing: {currentStudent.fullName || 'New Student'}
                </span>
                <span className="text-slate-500">·</span>
                <span className="font-mono text-emerald-400 font-bold">
                  LRN: {currentStudent.lrn || 'Pending'}
                </span>
                <span className="text-slate-500">·</span>
                <span className="text-slate-400">{currentStudent.level}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleNewStudent}
                  className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-semibold border border-slate-700 transition-colors flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5 text-emerald-400" />
                  New Student ID
                </button>
              </div>
            </div>

            {/* Split Grid: Form (Left) + Card Preview (Right) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
              {/* Left Column: Fillable Form (7 cols) */}
              <div className="lg:col-span-7">
                <StudentForm
                  student={currentStudent}
                  onChange={handleStudentChange}
                  onSaveToRegistry={handleSaveToRegistry}
                  onNewStudent={handleNewStudent}
                  isAdminUnlocked={isAdminUnlocked}
                  onUnlockAdmin={() => setIsAdminUnlocked(true)}
                  onLockAdmin={() => setIsAdminUnlocked(false)}
                />
              </div>

              {/* Right Column: Live 3D & Download Preview (5 cols) */}
              <div className="lg:col-span-5 sticky top-20">
                <IdCard3DPreview
                  student={currentStudent}
                  onOpenPrintModal={handlePrintCurrent}
                />
              </div>
            </div>

            {/* Registry Table: ADMIN ONLY (Removed from student access as requested) */}
            {isAdminUnlocked && (
              <div className="pt-4 animate-fade-in border-t border-slate-800">
                <div className="p-3 bg-amber-950/30 border border-amber-600/40 rounded-xl mb-3 flex items-center justify-between text-xs text-amber-200">
                  <span className="font-semibold flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-amber-400" />
                    School Administrator Registry ({students.length} students loaded)
                  </span>
                  <span className="text-[11px] text-amber-300">
                    Visible only to School Administration. Hidden from students.
                  </span>
                </div>
                <SpreadsheetManager
                  students={students}
                  activeStudentId={activeStudentId}
                  onSelectStudent={(s) => {
                    setActiveStudentId(s.id);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  onUpdateStudents={setStudents}
                  onBatchPrint={handleBatchPrint}
                />
              </div>
            )}
          </div>
        )}

        {/* VIEW 2: REGISTRY & SPREADSHEET MANAGER (ADMIN ACCESS ONLY) */}
        {activeNav === 'registry' && (
          <div className="space-y-6">
            {isAdminUnlocked ? (
              <SpreadsheetManager
                students={students}
                activeStudentId={activeStudentId}
                onSelectStudent={(s) => {
                  setActiveStudentId(s.id);
                  setActiveNav('designer');
                }}
                onUpdateStudents={setStudents}
                onBatchPrint={handleBatchPrint}
              />
            ) : (
              /* If Student clicks registry, show Admin login lock */
              <div className="bg-slate-900 border border-slate-800 rounded-2xl p-8 max-w-lg mx-auto text-center space-y-4">
                <div className="w-14 h-14 bg-amber-500/20 text-amber-400 border border-amber-500/40 rounded-2xl flex items-center justify-center mx-auto">
                  <Lock className="w-7 h-7" />
                </div>
                <h3 className="text-lg font-bold text-white font-oswald uppercase">
                  Administrator Access Required
                </h3>
                <p className="text-xs text-slate-400 max-w-md mx-auto">
                  The Student Spreadsheet Registry and export features contain personal student records and are restricted to authorized school personnel.
                </p>
                <div className="pt-2 flex justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => setActiveNav('designer')}
                    className="px-4 py-2 bg-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-semibold"
                  >
                    Back to Student Form
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowAdminLoginModal(true)}
                    className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-black rounded-xl text-xs font-bold"
                  >
                    Enter Admin PIN
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* VIEW 3: GUIDELINES & SPECIFICATIONS */}
        {activeNav === 'guidelines' && (
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-6 text-white max-w-4xl mx-auto shadow-xl">
            <div className="flex items-center gap-3 pb-4 border-b border-slate-800">
              <Info className="w-6 h-6 text-emerald-400 shrink-0" />
              <div>
                <h2 className="text-lg font-bold text-white font-oswald uppercase">
                  Sulon National High School ID Specifications
                </h2>
                <p className="text-xs text-slate-400">
                  Standard DepEd CR80 PVC ID Card Print Specifications &amp; Requirements
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
              <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/60 space-y-2">
                <h3 className="font-bold text-emerald-300 uppercase tracking-wider">
                  Physical Dimensions &amp; Cutting Margins
                </h3>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>Standard CR80 Size:</strong> 2.125&quot; x 3.370&quot; (53.98mm x 85.60mm)</li>
                  <li><strong>Bleed / Cutting Allowance:</strong> 3mm outer margin on all 4 sides with corner crop marks (┌ ┐ └ ┘)</li>
                  <li><strong>Safe Zone:</strong> Student signature and Principal name are adjusted comfortably away from cutting boundaries</li>
                  <li><strong>Background Fill:</strong> Continuous single background layer immediately below top header to bottom</li>
                </ul>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/60 space-y-2">
                <h3 className="font-bold text-yellow-300 uppercase tracking-wider">
                  Color Codes &amp; S.Y. Validity Notice
                </h3>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>Junior High:</strong> DepEd Green (#22c55e) with black 3D outline</li>
                  <li><strong>Senior High:</strong> Golden Yellow (#facc15) with black 3D outline</li>
                  <li><strong>No Printed S.Y.:</strong> School Year is manually stickered in the back sticker box</li>
                  <li><strong>Principal Signature:</strong> Removed by default, designation and title enlarged</li>
                </ul>
              </div>

              <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/60 space-y-2 md:col-span-2">
                <h3 className="font-bold text-sky-300 uppercase tracking-wider">
                  Role-Based Security &amp; Address Dropdown
                </h3>
                <ul className="list-disc list-inside space-y-1 text-slate-300">
                  <li><strong>Student Access:</strong> Can only fill out personal details (Full name, LRN, Photo, Signature, Birthday, Address, Guardian info)</li>
                  <li><strong>Address Selector:</strong> Cascade dropdowns (Province &gt; Municipality &gt; Barangay) prevents spelling mistakes</li>
                  <li><strong>Admin Access:</strong> Protects ID layout customization, colors, school seal, and the Student Spreadsheet Registry (PIN: 1234)</li>
                </ul>
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Admin Unlock Modal Dialog */}
      {showAdminLoginModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-amber-500/50 rounded-2xl max-w-md w-full p-6 shadow-2xl text-white space-y-4 animate-scale-in">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400 shrink-0">
                <Lock className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white font-oswald uppercase">
                  School Administrator Access
                </h3>
                <p className="text-xs text-slate-400">
                  Unlock to access the Student Spreadsheet Registry and School ID Template Customization.
                </p>
              </div>
            </div>

            <form onSubmit={handleAdminLoginSubmit} className="space-y-4 pt-2">
              <div>
                <label className="block text-xs font-semibold text-slate-300 mb-1.5">
                  Enter Admin PIN Code
                </label>
                <input
                  type="password"
                  value={adminPinInput}
                  onChange={(e) => setAdminPinInput(e.target.value)}
                  placeholder="••••••"
                  autoFocus
                  className="w-full bg-slate-800 border border-slate-700 focus:border-amber-500 rounded-xl px-4 py-2.5 text-sm font-mono tracking-widest text-center text-white focus:outline-none focus:ring-1 focus:ring-amber-500"
                />
                {pinError && (
                  <p className="text-xs text-rose-400 mt-1.5 font-medium">{pinError}</p>
                )}
              </div>

              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setShowAdminLoginModal(false)}
                  className="px-3 py-2 text-xs font-medium text-slate-300 hover:text-white rounded-lg bg-slate-800 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 text-xs font-bold text-black bg-amber-400 hover:bg-amber-300 rounded-lg transition-colors shadow-md"
                >
                  Unlock Admin
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Print Batch / Individual Modal */}
      {isPrintModalOpen && (
        <PrintModal
          studentsToPrint={studentsToPrint}
          onClose={() => setIsPrintModalOpen(false)}
        />
      )}
    </div>
  );
}
