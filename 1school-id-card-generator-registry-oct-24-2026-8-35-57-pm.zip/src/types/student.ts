export type EducationLevel = 'JUNIOR HIGH SCHOOL' | 'SENIOR HIGH SCHOOL' | 'ELEMENTARY' | 'CUSTOM';

export interface StudentRecord {
  id: string;
  // School Info
  republicHeader: string;
  regionHeader: string;
  ministryHeader: string;
  divisionHeader: string;
  schoolName: string;
  schoolAddress: string;
  schoolIdNumber: string;

  // School Logo & Background Customization
  schoolLogoUrl?: string; // Custom uploaded school logo/seal
  backgroundUrl?: string; // Custom uploaded card background (Plain white by default)
  backgroundOpacity?: number; // 0 to 1 (default 0.2)
  backgroundBlur?: number; // blur in px (default 0)
  showFrontLogoWatermark?: boolean; // Default false to prevent interference with uploaded backgrounds

  // Cutting Allowance Margin
  includeCuttingMargin?: boolean; // Margin on all sides for allowance on cutting
  cuttingMarginMm?: number; // Cutting margin in mm (default 3mm)

  // Level & Header Color Schemes
  juniorHighColor?: string; // e.g. '#22c55e'
  juniorHighStrokeColor?: string; // e.g. '#000000'
  seniorHighColor?: string; // e.g. '#facc15'
  seniorHighStrokeColor?: string; // e.g. '#000000'
  headerBgStart?: string; // e.g. '#15803d'
  headerBgEnd?: string; // e.g. '#4ade80'
  schoolNameColor?: string; // e.g. '#fde047'

  // Student Identity
  lrn: string; // 12-digit LRN
  fullName: string;
  level: EducationLevel;
  customLevel?: string;
  trackStrand?: string; // Optional track/strand for SHS

  // Student Personal Details
  birthDate: string; // YYYY-MM-DD
  studentAddress: string;

  // Emergency Contact
  emergencyContactName: string;
  emergencyContactAddress: string;
  emergencyContactPhone: string;

  // Images & Signatures
  photoUrl: string;
  photoScale?: number;
  photoOffsetX?: number;
  photoOffsetY?: number;
  signatureUrl: string;

  // Principal Details (Signature removed by user request, toggleable)
  showPrincipalSignature?: boolean; // Default false (removed per user request)
  principalName: string;
  principalTitle: string;
  principalSignatureUrl: string;

  // Metadata
  createdAt: string;
  updatedAt: string;
}

export interface PrintSettings {
  paperSize: 'A4' | 'Letter' | 'CR80';
  layout: 'single' | 'both-side-by-side' | 'sheet-4' | 'sheet-8';
  includeCropMarks: boolean;
  scalePercent: number;
  cuttingMarginMm: number; // Bleed / margin allowance on all sides
}
